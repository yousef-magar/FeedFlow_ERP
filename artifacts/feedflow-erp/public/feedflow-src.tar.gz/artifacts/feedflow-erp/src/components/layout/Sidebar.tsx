import React from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { 
  LayoutDashboard, 
  Factory, 
  Package, 
  ShoppingCart, 
  Users, 
  Truck, 
  UserCircle, 
  Banknote, 
  Briefcase, 
  Calculator, 
  FileText, 
  BarChart, 
  BotMessageSquare, 
  Settings,
  ChevronRight,
  LogOut,
  Moon,
  Sun,
  UserCog,
  LucideIcon,
} from "lucide-react";
import { useAppStore } from "@/hooks/use-app-store";

const MENU_MAP: Record<string, { icon: LucideIcon; ar: string; en: string }> = {
  "/": { icon: LayoutDashboard, ar: "الرئيسية", en: "Dashboard" },
  "/production": { icon: Factory, ar: "الإنتاج", en: "Production" },
  "/inventory": { icon: Package, ar: "المخزون", en: "Inventory" },
  "/sales": { icon: ShoppingCart, ar: "المبيعات", en: "Sales" },
  "/customers": { icon: Users, ar: "العملاء", en: "Customers" },
  "/fleet": { icon: Truck, ar: "الأسطول", en: "Fleet & Delivery" },
  "/hr": { icon: UserCircle, ar: "الموارد البشرية", en: "HR" },
  "/payroll": { icon: Banknote, ar: "الرواتب", en: "Payroll" },
  "/marketing": { icon: Briefcase, ar: "التسويق", en: "Marketing" },
  "/accounting": { icon: Calculator, ar: "الحسابات", en: "Accounting" },
  "/procurement": { icon: FileText, ar: "المشتريات", en: "Procurement" },
  "/reports": { icon: BarChart, ar: "التقارير", en: "Reports" },
  "/ai-assistant": { icon: BotMessageSquare, ar: "المساعد الذكي", en: "AI Assistant" },
  "/sub-accounts": { icon: UserCog, ar: "الحسابات الفرعية", en: "Sub Accounts" },
  "/settings": { icon: Settings, ar: "الإعدادات", en: "Settings" },
};

export function Sidebar({ collapsed, setCollapsed }: { collapsed: boolean; setCollapsed: (val: boolean) => void }) {
  const [location] = useLocation();
  const { t, theme, setTheme, sidebarOrder } = useAppStore();

  const menuItems = sidebarOrder
    .filter(path => MENU_MAP[path])
    .map(path => ({ path, ...MENU_MAP[path] }));

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 80 : 280 }}
      className="bg-sidebar border-x border-sidebar-border h-screen flex flex-col fixed z-40"
    >
      <div className="h-16 flex items-center justify-between px-4 border-b border-sidebar-border">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="font-bold text-lg text-primary flex items-center gap-2"
          >
            <div className="w-8 h-8 rounded bg-primary text-primary-foreground flex items-center justify-center text-xl">
              F
            </div>
            FeedFlow ERP
          </motion.div>
        )}
        {collapsed && (
          <div className="w-full flex justify-center">
            <div className="w-8 h-8 rounded bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold">
              F
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto py-4 flex flex-col gap-1 px-3 custom-scrollbar">
        {menuItems.map((item) => {
          const isActive = location === item.path;
          const Icon = item.icon;
          return (
            <Link key={item.path} href={item.path}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors relative group ${
                  isActive 
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" 
                    : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                } ${collapsed ? "justify-center" : ""}`}
              >
                {isActive && (
                  <motion.div 
                    layoutId="active-nav-indicator"
                    className="absolute right-0 top-0 bottom-0 w-1 bg-primary rounded-l-md"
                  />
                )}
                <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? "text-primary" : "text-sidebar-foreground/70"}`} />
                {!collapsed && (
                  <span className="truncate">{t(item.ar, item.en)}</span>
                )}
                
                {collapsed && (
                  <div className="absolute right-14 bg-popover text-popover-foreground px-2 py-1 rounded shadow-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                    {t(item.ar, item.en)}
                  </div>
                )}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="p-4 border-t border-sidebar-border flex flex-col gap-2">
        {!collapsed ? (
          <>
             <div 
              className="flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer hover:bg-sidebar-accent/50 text-sidebar-foreground transition-colors"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-sidebar-foreground/70" /> : <Moon className="w-5 h-5 text-sidebar-foreground/70" />}
              <span>{theme === 'dark' ? t('الوضع الفاتح', 'Light Mode') : t('الوضع الداكن', 'Dark Mode')}</span>
            </div>
            <Link href="/login">
              <div className="flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer hover:bg-destructive/10 text-destructive transition-colors">
                <LogOut className="w-5 h-5" />
                <span>{t("تسجيل الخروج", "Logout")}</span>
              </div>
            </Link>
          </>
        ) : (
          <>
            <div 
              className="flex justify-center p-2 rounded-md cursor-pointer hover:bg-sidebar-accent/50 text-sidebar-foreground transition-colors group relative"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              <div className="absolute right-14 bg-popover text-popover-foreground px-2 py-1 rounded shadow-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                {theme === 'dark' ? t('الوضع الفاتح', 'Light Mode') : t('الوضع الداكن', 'Dark Mode')}
              </div>
            </div>
            <Link href="/login">
              <div className="flex justify-center p-2 rounded-md cursor-pointer hover:bg-destructive/10 text-destructive transition-colors group relative">
                <LogOut className="w-5 h-5" />
                <div className="absolute right-14 bg-popover text-popover-foreground px-2 py-1 rounded shadow-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  {t("تسجيل الخروج", "Logout")}
                </div>
              </div>
            </Link>
          </>
        )}
      </div>

      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute top-6 -left-3 w-6 h-6 bg-sidebar-accent border border-sidebar-border rounded-full flex items-center justify-center text-sidebar-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors shadow-sm"
      >
        <ChevronRight className={`w-4 h-4 transition-transform ${collapsed ? "rotate-180" : ""}`} />
      </button>
    </motion.aside>
  );
}
