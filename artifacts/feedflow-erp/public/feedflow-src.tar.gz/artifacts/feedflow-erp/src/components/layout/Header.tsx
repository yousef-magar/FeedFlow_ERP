import React from "react";
import { Bell, Search, Globe } from "lucide-react";
import { useAppStore } from "@/hooks/use-app-store";
import { motion } from "framer-motion";

export function Header() {
  const { language, setLanguage, t } = useAppStore();

  return (
    <header className="h-16 border-b border-border bg-card flex items-center justify-between px-6 sticky top-0 z-30">
      <div className="flex items-center gap-4 flex-1">
        <div className="relative w-full max-w-md hidden md:block">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input 
            type="text" 
            placeholder={t("بحث في النظام...", "Search system...")}
            className="w-full h-10 bg-muted/50 border-none rounded-md pr-10 pl-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-shadow"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
          className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-md hover:bg-muted/50"
        >
          <Globe className="w-4 h-4" />
          {language === "ar" ? "English" : "عربي"}
        </button>

        <div className="relative cursor-pointer w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted/50 transition-colors">
          <Bell className="w-5 h-5 text-muted-foreground" />
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full border-2 border-card"
          />
        </div>

        <div className="flex items-center gap-3 pr-4 border-r border-border">
          <div className="text-left rtl:text-right hidden sm:block">
            <p className="text-sm font-semibold leading-none">أحمد محمود</p>
            <p className="text-xs text-muted-foreground mt-1">مدير المصنع</p>
          </div>
          <div className="w-9 h-9 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold">
            AM
          </div>
        </div>
      </div>
    </header>
  );
}
