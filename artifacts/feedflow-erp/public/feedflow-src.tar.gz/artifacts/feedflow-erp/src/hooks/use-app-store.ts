import { create } from "zustand";

type Language = "ar" | "en";
type Theme = "dark" | "light";

export type Permission = "none" | "view" | "full";

export interface SubAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  role: string;
  active: boolean;
  permissions: Record<string, Permission>;
  createdAt: string;
}

const ALL_MODULE_PATHS = [
  "/", "/production", "/inventory", "/sales", "/customers",
  "/fleet", "/hr", "/payroll", "/marketing", "/accounting",
  "/procurement", "/reports", "/ai-assistant", "/settings", "/sub-accounts"
];

const DEFAULT_SIDEBAR_ORDER = [
  "/", "/production", "/inventory", "/sales", "/customers",
  "/fleet", "/hr", "/payroll", "/marketing", "/accounting",
  "/procurement", "/reports", "/ai-assistant", "/sub-accounts", "/settings"
];

interface AppState {
  language: Language;
  theme: Theme;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  t: (ar: string, en: string) => string;
  sidebarOrder: string[];
  setSidebarOrder: (order: string[]) => void;
  subAccounts: SubAccount[];
  addSubAccount: (account: Omit<SubAccount, "id" | "createdAt">) => void;
  updateSubAccount: (id: string, updates: Partial<SubAccount>) => void;
  deleteSubAccount: (id: string) => void;
}

const getInitialLang = (): Language => {
  const saved = localStorage.getItem("feedflow-lang") as Language;
  return saved || "ar";
};

const getInitialTheme = (): Theme => {
  const saved = localStorage.getItem("feedflow-theme") as Theme;
  return saved || "dark";
};

const getInitialSidebarOrder = (): string[] => {
  try {
    const saved = localStorage.getItem("feedflow-sidebar-order");
    if (saved) {
      const parsed = JSON.parse(saved) as string[];
      const allPaths = new Set(DEFAULT_SIDEBAR_ORDER);
      const savedSet = new Set(parsed);
      const newPaths = DEFAULT_SIDEBAR_ORDER.filter(p => !savedSet.has(p));
      const validPaths = parsed.filter(p => allPaths.has(p));
      return [...validPaths, ...newPaths];
    }
  } catch {}
  return DEFAULT_SIDEBAR_ORDER;
};

const getInitialSubAccounts = (): SubAccount[] => {
  try {
    const saved = localStorage.getItem("feedflow-sub-accounts");
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
};

const applyLang = (lang: Language) => {
  document.documentElement.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
  document.documentElement.setAttribute("lang", lang);
};

const applyTheme = (theme: Theme) => {
  if (theme === "dark") {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
};

applyLang(getInitialLang());
applyTheme(getInitialTheme());

export const useAppStore = create<AppState>((set, get) => ({
  language: getInitialLang(),
  theme: getInitialTheme(),
  setLanguage: (lang) => {
    localStorage.setItem("feedflow-lang", lang);
    applyLang(lang);
    set({ language: lang });
  },
  setTheme: (theme) => {
    localStorage.setItem("feedflow-theme", theme);
    applyTheme(theme);
    set({ theme });
  },
  t: (ar, en) => {
    return get().language === "ar" ? ar : en;
  },
  sidebarOrder: getInitialSidebarOrder(),
  setSidebarOrder: (order) => {
    localStorage.setItem("feedflow-sidebar-order", JSON.stringify(order));
    set({ sidebarOrder: order });
  },
  subAccounts: getInitialSubAccounts(),
  addSubAccount: (account) => {
    const newAccount: SubAccount = {
      ...account,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const updated = [...state.subAccounts, newAccount];
      localStorage.setItem("feedflow-sub-accounts", JSON.stringify(updated));
      return { subAccounts: updated };
    });
  },
  updateSubAccount: (id, updates) => {
    set((state) => {
      const updated = state.subAccounts.map(a => a.id === id ? { ...a, ...updates } : a);
      localStorage.setItem("feedflow-sub-accounts", JSON.stringify(updated));
      return { subAccounts: updated };
    });
  },
  deleteSubAccount: (id) => {
    set((state) => {
      const updated = state.subAccounts.filter(a => a.id !== id);
      localStorage.setItem("feedflow-sub-accounts", JSON.stringify(updated));
      return { subAccounts: updated };
    });
  },
}));

export { ALL_MODULE_PATHS, DEFAULT_SIDEBAR_ORDER };
