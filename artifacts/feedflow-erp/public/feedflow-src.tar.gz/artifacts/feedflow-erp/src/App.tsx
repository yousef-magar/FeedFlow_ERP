import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import { MainLayout } from "@/components/layout/MainLayout";
import Dashboard from "@/pages/Dashboard";
import Login from "@/pages/Login";
import Inventory from "@/pages/Inventory";
import Customers from "@/pages/Customers";
import Sales from "@/pages/Sales";
import Production from "@/pages/Production";
import AiAssistant from "@/pages/AiAssistant";
import Fleet from "@/pages/Fleet";
import HR from "@/pages/HR";
import Payroll from "@/pages/Payroll";
import Marketing from "@/pages/Marketing";
import Accounting from "@/pages/Accounting";
import Procurement from "@/pages/Procurement";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import SubAccounts from "@/pages/SubAccounts";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      <Route path="*">
        <MainLayout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/production" component={Production} />
            <Route path="/inventory" component={Inventory} />
            <Route path="/sales" component={Sales} />
            <Route path="/customers" component={Customers} />
            <Route path="/ai-assistant" component={AiAssistant} />
            <Route path="/fleet" component={Fleet} />
            <Route path="/hr" component={HR} />
            <Route path="/payroll" component={Payroll} />
            <Route path="/marketing" component={Marketing} />
            <Route path="/accounting" component={Accounting} />
            <Route path="/procurement" component={Procurement} />
            <Route path="/reports" component={Reports} />
            <Route path="/sub-accounts" component={SubAccounts} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
        </MainLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
