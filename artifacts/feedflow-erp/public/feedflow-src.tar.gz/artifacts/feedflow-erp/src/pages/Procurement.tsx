import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, Plus, ShoppingBag, CheckCircle2, Package, DollarSign, ChevronLeft } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const materials = ["ذرة صفراء أوكراني", "صويا أرجنتيني 46%", "جلوتين ذرة مستورد", "نخالة (ردة) محلية", "فيتامينات بريمكس", "مضاد سموم فطرية", "كالسيوم"];

export default function Procurement() {
  const { t } = useAppStore();
  const [poOpen, setPoOpen] = useState(false);
  const [supplierDetailOpen, setSupplierDetailOpen] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);

  const [suppliers, setSuppliers] = useState(mockData.suppliers);
  const [purchaseOrders, setPurchaseOrders] = useState([
    { id: "PO-2023-015", supplierId: "S1", supplierName: mockData.suppliers[0].name, material: "ذرة صفراء", qty: 500, unit: "طن", unitPrice: 9500, total: 4750000, status: "approved", date: "2023-12-10" },
    { id: "PO-2023-014", supplierId: "S2", supplierName: mockData.suppliers[1].name, material: "صويا أرجنتيني", qty: 200, unit: "طن", unitPrice: 24000, total: 4800000, status: "pending", date: "2023-12-08" },
  ]);

  // PO Form
  const [poSupplierId, setPoSupplierId] = useState("");
  const [poMaterial, setPoMaterial] = useState("");
  const [poQty, setPoQty] = useState("");
  const [poUnitPrice, setPoUnitPrice] = useState("");
  const [poUnit, setPoUnit] = useState("طن");

  const poTotal = (parseFloat(poQty) || 0) * (parseFloat(poUnitPrice) || 0);

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleSubmitPO = () => {
    if (!poSupplierId || !poMaterial || !poQty || !poUnitPrice) return;
    const sup = suppliers.find(s => s.id === poSupplierId);
    const newPO = {
      id: `PO-2024-${String(purchaseOrders.length + 1).padStart(3, "0")}`,
      supplierId: poSupplierId,
      supplierName: sup?.name || "",
      material: poMaterial,
      qty: parseFloat(poQty),
      unit: poUnit,
      unitPrice: parseFloat(poUnitPrice),
      total: poTotal,
      status: "pending",
      date: new Date().toISOString().split("T")[0],
    };
    setPurchaseOrders(prev => [newPO, ...prev]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false); setPoOpen(false);
      setPoSupplierId(""); setPoMaterial(""); setPoQty(""); setPoUnitPrice(""); setPoUnit("طن");
    }, 1400);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved": return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t("معتمد", "Approved")}</Badge>;
      case "pending": return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20">{t("معلق", "Pending")}</Badge>;
      case "delivered": return <Badge className="bg-primary/10 text-primary border-primary/20">{t("تم التسليم", "Delivered")}</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("المشتريات والموردين", "Procurement")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة الموردين وأوامر الشراء للخامات", "Manage suppliers and raw material POs")}</p>
        </div>
        <Button className="gap-2" onClick={() => setPoOpen(true)} data-testid="button-new-po">
          <Plus className="w-4 h-4" />
          {t("أمر شراء جديد", "New PO")}
        </Button>
      </div>

      {/* Suppliers */}
      <div>
        <h2 className="text-lg font-semibold mb-4">{t("الموردين", "Suppliers")}</h2>
        <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {suppliers.map(s => (
            <motion.div variants={itemVariants} key={s.id}>
              <Card
                className="p-5 flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow group"
                onClick={() => { setSelectedSupplier(s); setSupplierDetailOpen(true); }}
                data-testid={`card-supplier-${s.id}`}
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 text-primary rounded-lg"><ShoppingBag className="w-6 h-6" /></div>
                  <div>
                    <h3 className="font-bold group-hover:text-primary transition-colors">{s.name}</h3>
                    <p className="text-sm text-muted-foreground">{s.material}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-destructive">{formatCurrency(s.balance)}</p>
                  <p className="text-xs text-muted-foreground">{t("رصيد مستحق", "Outstanding")}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Purchase Orders */}
      <div>
        <h2 className="text-lg font-semibold mb-4">{t("أوامر الشراء", "Purchase Orders")}</h2>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left rtl:text-right">
              <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
                <tr>
                  <th className="px-6 py-4">{t("رقم الأمر", "PO No.")}</th>
                  <th className="px-6 py-4">{t("المورد", "Supplier")}</th>
                  <th className="px-6 py-4">{t("الخامة", "Material")}</th>
                  <th className="px-6 py-4">{t("الكمية", "Qty")}</th>
                  <th className="px-6 py-4">{t("الإجمالي", "Total")}</th>
                  <th className="px-6 py-4">{t("الحالة", "Status")}</th>
                </tr>
              </thead>
              <motion.tbody variants={containerVariants} initial="hidden" animate="show">
                <AnimatePresence>
                  {purchaseOrders.map((po) => (
                    <motion.tr variants={itemVariants} key={po.id} layout className="border-b border-border hover:bg-muted/30 transition-colors" data-testid={`row-po-${po.id}`}>
                      <td className="px-6 py-4 font-medium text-primary">{po.id}</td>
                      <td className="px-6 py-4">{po.supplierName}</td>
                      <td className="px-6 py-4">{po.material}</td>
                      <td className="px-6 py-4">{po.qty} {po.unit}</td>
                      <td className="px-6 py-4 font-bold">{formatCurrency(po.total)}</td>
                      <td className="px-6 py-4">{getStatusBadge(po.status)}</td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </motion.tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* New PO Sheet */}
      <Sheet open={poOpen} onOpenChange={setPoOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("أمر شراء جديد", "New Purchase Order")}</SheetTitle>
            <SheetDescription>{t("أنشئ أمر شراء خامات من أحد الموردين", "Create a raw material purchase order from a supplier")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("المورد", "Supplier")}</Label>
              <Select value={poSupplierId} onValueChange={setPoSupplierId}>
                <SelectTrigger data-testid="select-po-supplier"><SelectValue placeholder={t("اختر المورد", "Select supplier")} /></SelectTrigger>
                <SelectContent>
                  {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("الخامة المطلوبة", "Required Material")}</Label>
              <Select value={poMaterial} onValueChange={setPoMaterial}>
                <SelectTrigger data-testid="select-po-material"><SelectValue placeholder={t("اختر الخامة", "Select material")} /></SelectTrigger>
                <SelectContent>
                  {materials.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2 space-y-2">
                <Label>{t("الكمية", "Quantity")}</Label>
                <Input type="number" min="0" placeholder="0" value={poQty} onChange={e => setPoQty(e.target.value)} data-testid="input-po-qty" />
              </div>
              <div className="space-y-2">
                <Label>{t("الوحدة", "Unit")}</Label>
                <Select value={poUnit} onValueChange={setPoUnit}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="طن">{t("طن", "Ton")}</SelectItem>
                    <SelectItem value="كجم">{t("كجم", "Kg")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("سعر الوحدة (ج.م)", "Unit Price (EGP)")}</Label>
              <Input type="number" min="0" placeholder="0" value={poUnitPrice} onChange={e => setPoUnitPrice(e.target.value)} data-testid="input-po-unit-price" />
            </div>
            {poTotal > 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 bg-muted/30 rounded-lg flex justify-between items-center">
                <span className="font-medium">{t("إجمالي الأمر", "Order Total")}</span>
                <span className="text-xl font-bold text-primary">{formatCurrency(poTotal)}</span>
              </motion.div>
            )}
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم إنشاء أمر الشراء!", "PO created!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleSubmitPO} disabled={!poSupplierId || !poMaterial || !poQty || !poUnitPrice} data-testid="button-submit-po">
                    {t("إنشاء أمر الشراء", "Create PO")}
                  </Button>
                  <Button variant="outline" onClick={() => setPoOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Supplier Detail Dialog */}
      <Dialog open={supplierDetailOpen} onOpenChange={setSupplierDetailOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("تفاصيل المورد", "Supplier Details")}</DialogTitle>
          </DialogHeader>
          {selectedSupplier && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <div className="p-3 bg-primary/10 text-primary rounded-lg"><ShoppingBag className="w-8 h-8" /></div>
                <div>
                  <p className="font-bold text-lg">{selectedSupplier.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedSupplier.material}</p>
                  <Badge className="mt-1 bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t("نشط", "Active")}</Badge>
                </div>
              </div>
              <div className="flex justify-between py-3 border-b border-border">
                <span className="text-muted-foreground text-sm flex items-center gap-2"><DollarSign className="w-4 h-4" />{t("الرصيد المستحق", "Outstanding Balance")}</span>
                <span className="font-bold text-destructive">{formatCurrency(selectedSupplier.balance)}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2">
                <Button className="gap-2" onClick={() => { setSupplierDetailOpen(false); setPoOpen(true); setPoSupplierId(selectedSupplier.id); }} data-testid="button-create-po-for-supplier">
                  <Plus className="w-4 h-4" />{t("أمر شراء", "New PO")}
                </Button>
                <Button variant="outline" className="gap-2 text-emerald-500 border-emerald-500/40 hover:bg-emerald-500/10" data-testid="button-pay-supplier">
                  <DollarSign className="w-4 h-4" />{t("تسوية مديونية", "Settle Debt")}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
