import React, { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useAppStore } from "@/hooks/use-app-store";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Factory, Lock, Mail, Globe, Moon, Sun, ArrowRight } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { t, language, setLanguage, theme, setTheme } = useAppStore();
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Mock login
    setTimeout(() => {
      setLocation("/");
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full flex flex-col md:flex-row bg-background">
      {/* Left side - Login Form */}
      <div className="w-full md:w-1/2 flex flex-col justify-center px-8 md:px-16 lg:px-24 xl:px-32 relative z-10">
        
        {/* Top Controls */}
        <div className="absolute top-6 left-6 right-6 flex justify-between items-center">
          <div className="flex items-center gap-2 text-primary font-bold text-xl md:hidden">
            <div className="w-8 h-8 rounded bg-primary text-primary-foreground flex items-center justify-center">F</div>
            FeedFlow ERP
          </div>
          <div className="flex items-center gap-4 ml-auto md:ml-0">
            <button 
              onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
              className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Globe className="w-4 h-4" />
              {language === "ar" ? "English" : "عربي"}
            </button>
            <button 
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md mx-auto"
        >
          <div className="mb-10">
            <h1 className="text-4xl font-bold tracking-tight mb-3">{t("مرحباً بك مجدداً", "Welcome Back")}</h1>
            <p className="text-muted-foreground text-lg">
              {t("سجل دخولك للوصول إلى لوحة التحكم", "Sign in to access your dashboard")}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">{t("البريد الإلكتروني", "Email Address")}</Label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="admin@factory.com" 
                  className="pr-10 h-12 text-base"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">{t("كلمة المرور", "Password")}</Label>
                <a href="#" className="text-sm font-medium text-primary hover:underline">
                  {t("نسيت كلمة المرور؟", "Forgot password?")}
                </a>
              </div>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="••••••••" 
                  className="pr-10 h-12 text-base"
                  required
                />
              </div>
            </div>

            <Button type="submit" className="w-full h-12 text-base font-semibold group relative overflow-hidden" disabled={loading}>
              <span className={`transition-opacity ${loading ? "opacity-0" : "opacity-100"} flex items-center gap-2`}>
                {t("تسجيل الدخول", "Sign In")}
                <ArrowRight className="w-5 h-5 rtl:rotate-180 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
              </span>
              {loading && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-6 h-6 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin"></div>
                </div>
              )}
            </Button>
          </form>
        </motion.div>
      </div>

      {/* Right side - Branding/Image */}
      <div className="hidden md:flex w-1/2 bg-sidebar relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
        
        {/* Abstract shapes / Patterns */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-chart-2/20 blur-[120px]" />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative z-10 text-center max-w-lg"
        >
          <div className="w-24 h-24 mx-auto bg-primary text-primary-foreground rounded-2xl flex items-center justify-center mb-8 shadow-xl shadow-primary/20">
            <Factory className="w-12 h-12" />
          </div>
          <h2 className="text-4xl font-bold tracking-tight mb-4 text-foreground">
            FeedFlow ERP <span className="text-primary">AI</span>
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            {t(
              "نظام إدارة مصانع الأعلاف الأذكى والأكثر تطوراً. تحكم كامل، دقة متناهية، وقرارات مدعومة بالذكاء الاصطناعي.",
              "The smartest and most advanced feed factory management system. Full control, ultimate precision, and AI-powered decisions."
            )}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
