import React from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { BarChart as BarChartIcon, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const data = [
  { name: 'يناير', profit: 4000 },
  { name: 'فبراير', profit: 3000 },
  { name: 'مارس', profit: 2000 },
  { name: 'أبريل', profit: 2780 },
  { name: 'مايو', profit: 1890 },
  { name: 'يونيو', profit: 2390 },
];

export default function Reports() {
  const { t } = useAppStore();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("التقارير", "Reports")}</h1>
          <p className="text-muted-foreground mt-1">{t("تحليلات متقدمة للأداء", "Advanced analytics and reports")}</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          {t("تصدير PDF", "Export PDF")}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {['المبيعات', 'المخزون', 'الإنتاج', 'الحسابات'].map((cat) => (
          <Card key={cat} className="p-4 hover:border-primary/50 transition-colors cursor-pointer group flex items-center gap-3">
            <div className="p-2 bg-primary/10 text-primary rounded-md group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
              <BarChartIcon className="w-5 h-5" />
            </div>
            <span className="font-medium">{t(`تقارير ${cat}`, `${cat} Reports`)}</span>
          </Card>
        ))}
      </div>

      <Card className="p-6">
        <h3 className="font-bold text-lg mb-6">{t("تحليل الأرباح الشهري", "Monthly Profit Analysis")}</h3>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
              <YAxis stroke="hsl(var(--muted-foreground))" axisLine={false} tickLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                cursor={{fill: 'hsl(var(--muted)/0.5)'}}
              />
              <Bar dataKey="profit" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
