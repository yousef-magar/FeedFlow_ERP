import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";
import { Factory, Cog, CheckCircle2, Clock, Plus, FlaskConical, ChevronLeft } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const formulas: Record<string, { material: string; pct: number }[]> = {
  P1: [
    { material: "ذرة صفراء", pct: 60 },
    { material: "صويا أرجنتيني", pct: 25 },
    { material: "جلوتين ذرة", pct: 10 },
    { material: "فيتامينات بريمكس", pct: 5 },
  ],
  P2: [
    { material: "ذرة صفراء", pct: 55 },
    { material: "صويا أرجنتيني", pct: 30 },
    { material: "جلوتين ذرة", pct: 10 },
    { material: "فيتامينات بريمكس", pct: 5 },
  ],
  P3: [
    { material: "ذرة صفراء", pct: 62 },
    { material: "صويا أرجنتيني", pct: 22 },
    { material: "نخالة محلية", pct: 10 },
    { material: "فيتامينات بريمكس", pct: 6 },
  ],
  P4: [
    { material: "ذرة صفراء", pct: 50 },
    { material: "نخالة محلية", pct: 25 },
    { material: "صويا أرجنتيني", pct: 20 },
    { material: "فيتامينات بريمكس", pct: 5 },
  ],
  P5: [
    { material: "ذرة صفراء", pct: 58 },
    { material: "نخالة محلية", pct: 22 },
    { material: "صويا أرجنتيني", pct: 15 },
    { material: "فيتامينات بريمكس", pct: 5 },
  ],
};

export default function Production() {
  const { t } = useAppStore();
  const { products } = mockData;

  const [sheetOpen, setSheetOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [selectedProductId, setSelectedProductId] = useState("");
  const [targetTons, setTargetTons] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const [orders, setOrders] = useState([
    { id: "PRD-0042", productId: "P1", productName: products[0].name, targetTons: 50, status: "in-progress", progress: 65, date: "2023-12-15" },
    { id: "PRD-0043", productId: "P4", productName: products[3].name, targetTons: 30, status: "pending", progress: 0, date: "2023-12-16" },
    { id: "PRD-0041", productId: "P2", productName: products[1].name, targetTons: 100, status: "completed", progress: 100, date: "2023-12-14" },
  ]);

  const selectedProduct = products.find(p => p.id === selectedProductId);
  const tons = parseFloat(targetTons) || 0;
  const formula = selectedProductId ? formulas[selectedProductId] || [] : [];
  const costPerTon = selectedProduct ? (selectedProduct.wholeSalePrice * 1000) / selectedProduct.bagWeight / 20 : 0;

  const handleSubmit = () => {
    if (!selectedProductId || !targetTons) return;
    const prod = products.find(p => p.id === selectedProductId);
    if (!prod) return;
    const newOrder = {
      id: `PRD-${String(orders.length + 44).padStart(4, "0")}`,
      productId: selectedProductId,
      productName: prod.name,
      targetTons: tons,
      status: "pending",
      progress: 0,
      date: new Date().toISOString().split("T")[0],
    };
    setOrders(prev => [newOrder, ...prev]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setSheetOpen(false);
      setSelectedProductId("");
      setTargetTons("");
    }, 1500);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case "in-progress": return <Cog className="w-4 h-4 text-primary" />;
      case "pending": return <Clock className="w-4 h-4 text-amber-500" />;
      default: return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return t("مكتمل", "Completed");
      case "in-progress": return t("جاري الإنتاج", "In Progress");
      case "pending": return t("قيد الانتظار", "Pending");
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الإنتاج", "Production")}</h1>
          <p className="text-muted-foreground mt-1">{t("أوامر التشغيل ومراقبة خطوط الإنتاج", "Work orders and production line monitoring")}</p>
        </div>
        <Button className="gap-2" data-testid="button-new-production-order" onClick={() => setSheetOpen(true)}>
          <Plus className="w-4 h-4" />
          {t("أمر إنتاج جديد", "New Order")}
        </Button>
      </div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6"
      >
        <AnimatePresence>
          {orders.map((order) => (
            <motion.div variants={itemVariants} key={order.id} layout>
              <Card
                className={`p-6 relative overflow-hidden cursor-pointer hover:shadow-lg transition-shadow ${order.status === "in-progress" ? "border-primary/50 shadow-md shadow-primary/10" : ""}`}
                data-testid={`card-production-order-${order.id}`}
                onClick={() => { setSelectedOrder(order); setDetailOpen(true); }}
              >
                {order.status === "in-progress" && (
                  <div className="absolute top-0 left-0 w-full h-1 bg-primary/20">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${order.progress}%` }}
                      className="h-full bg-primary"
                      transition={{ duration: 1 }}
                    />
                  </div>
                )}

                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-md ${order.status === "in-progress" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                      <Factory className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold">{order.id}</h3>
                      <p className="text-xs text-muted-foreground">{order.date}</p>
                    </div>
                  </div>
                  <Badge variant={order.status === "in-progress" ? "default" : "outline"} className="flex items-center gap-1.5">
                    {getStatusIcon(order.status)}
                    {getStatusText(order.status)}
                  </Badge>
                </div>

                <div className="mb-6">
                  <p className="text-sm text-muted-foreground mb-1">{t("المنتج:", "Product:")}</p>
                  <p className="font-semibold text-lg">{order.productName}</p>
                </div>

                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{t("الكمية المستهدفة:", "Target Qty:")}</p>
                    <p className="font-bold text-2xl">{order.targetTons} <span className="text-base font-normal text-muted-foreground">{t("طن", "Tons")}</span></p>
                  </div>
                  {order.status === "in-progress" && (
                    <div className="text-right">
                      <p className="text-sm font-medium text-primary mb-1">{order.progress}%</p>
                      <p className="text-xs text-muted-foreground">{t("مكتمل", "Completed")}</p>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex items-center gap-1 text-xs text-primary opacity-70">
                  <span>{t("انقر للتفاصيل", "Click for details")}</span>
                  <ChevronLeft className="w-3 h-3 rtl:rotate-180" />
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* New Production Order Sheet */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("أمر إنتاج جديد", "New Production Order")}</SheetTitle>
            <SheetDescription>{t("حدد المنتج والكمية وسيقوم النظام بحساب الخامات تلقائيًا", "Select product and quantity — raw materials are calculated automatically")}</SheetDescription>
          </SheetHeader>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label>{t("المنتج", "Product")}</Label>
              <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                <SelectTrigger data-testid="select-production-product">
                  <SelectValue placeholder={t("اختر المنتج...", "Select product...")} />
                </SelectTrigger>
                <SelectContent>
                  {products.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t("الكمية المستهدفة (طن)", "Target Quantity (Tons)")}</Label>
              <Input
                type="number"
                min="1"
                placeholder="0"
                value={targetTons}
                onChange={e => setTargetTons(e.target.value)}
                data-testid="input-production-tons"
              />
            </div>

            {selectedProductId && tons > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-lg border border-border bg-muted/30 p-4 space-y-3"
              >
                <div className="flex items-center gap-2 mb-3">
                  <FlaskConical className="w-4 h-4 text-primary" />
                  <span className="font-semibold text-sm">{t("الخامات المطلوبة", "Required Raw Materials")}</span>
                </div>
                {formula.map((ing, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{ing.material}</span>
                      <span className="font-bold text-primary">{((tons * ing.pct) / 100).toFixed(1)} {t("طن", "ton")}</span>
                    </div>
                    <motion.div
                      className="h-1.5 bg-muted rounded-full overflow-hidden"
                      initial={false}
                    >
                      <motion.div
                        className="h-full bg-primary rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${ing.pct}%` }}
                        transition={{ duration: 0.6, delay: i * 0.1 }}
                      />
                    </motion.div>
                    <p className="text-xs text-muted-foreground text-left">{ing.pct}%</p>
                  </div>
                ))}
                <div className="pt-2 border-t border-border flex justify-between text-sm font-semibold">
                  <span>{t("تكلفة الإنتاج التقديرية", "Est. Production Cost")}</span>
                  <span className="text-primary">{new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(tons * costPerTon * 1000)}</span>
                </div>
              </motion.div>
            )}

            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div
                  key="success"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span className="font-medium">{t("تم إنشاء الأمر بنجاح!", "Order created successfully!")}</span>
                </motion.div>
              ) : (
                <motion.div key="btn" className="flex gap-3">
                  <Button className="flex-1" onClick={handleSubmit} disabled={!selectedProductId || !targetTons} data-testid="button-submit-production-order">
                    {t("إنشاء أمر الإنتاج", "Create Production Order")}
                  </Button>
                  <Button variant="outline" onClick={() => setSheetOpen(false)} data-testid="button-cancel-production">
                    {t("إلغاء", "Cancel")}
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Order Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("تفاصيل أمر الإنتاج", "Production Order Details")}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground text-sm">{t("رقم الأمر", "Order No.")}</span>
                <span className="font-bold">{selectedOrder.id}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground text-sm">{t("المنتج", "Product")}</span>
                <span className="font-semibold">{selectedOrder.productName}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground text-sm">{t("الكمية", "Quantity")}</span>
                <span className="font-bold">{selectedOrder.targetTons} {t("طن", "Tons")}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground text-sm">{t("التاريخ", "Date")}</span>
                <span>{selectedOrder.date}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-muted-foreground text-sm">{t("الحالة", "Status")}</span>
                <Badge variant="outline" className="flex items-center gap-1.5">
                  {getStatusIcon(selectedOrder.status)}
                  {getStatusText(selectedOrder.status)}
                </Badge>
              </div>
              {selectedOrder.status === "in-progress" && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{t("تقدم الإنتاج", "Production Progress")}</span>
                    <span className="font-bold text-primary">{selectedOrder.progress}%</span>
                  </div>
                  <Progress value={selectedOrder.progress} className="h-3" />
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
