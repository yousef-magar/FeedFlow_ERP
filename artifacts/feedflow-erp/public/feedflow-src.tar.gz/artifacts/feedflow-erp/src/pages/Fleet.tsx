import React, { useState, useEffect } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Truck, MapPin, Navigation, Plus, Cpu, CheckCircle2, Route, Package, User, Phone } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const aiSteps = [
  "تحليل عناوين التسليم...",
  "تجميع الطلبات المتجاورة...",
  "اختيار السيارات المناسبة...",
  "حساب أفضل مسار...",
  "تحسين ترتيب التوصيل...",
  "اكتمل التحسين!",
];

const suggestedRoutes = [
  { vehicle: "نقل ثقيل - ع ن 1234", driver: "محمد سعيد", stops: ["مزارع الوطنية", "شركة الأماني", "مؤسسة النور"], distance: "145 كم", eta: "4 ساعات" },
  { vehicle: "نصف نقل - د ر 9012", driver: "محمود حسن", stops: ["شركة الفيروز", "مزارع الوادي الجديد"], distance: "210 كم", eta: "6 ساعات" },
];

export default function Fleet() {
  const { t } = useAppStore();
  const [aiOpen, setAiOpen] = useState(false);
  const [addVehicleOpen, setAddVehicleOpen] = useState(false);
  const [vehicleDetailOpen, setVehicleDetailOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);

  const [aiStep, setAiStep] = useState(0);
  const [aiDone, setAiDone] = useState(false);
  const [aiRunning, setAiRunning] = useState(false);

  const [vehicles, setVehicles] = useState(mockData.fleet);
  const [vehicleName, setVehicleName] = useState("");
  const [driverName, setDriverName] = useState("");
  const [vehicleType, setVehicleType] = useState("");
  const [addDone, setAddDone] = useState(false);

  const runAi = () => {
    setAiStep(0);
    setAiDone(false);
    setAiRunning(true);
  };

  useEffect(() => {
    if (!aiRunning) return;
    if (aiStep >= aiSteps.length - 1) {
      setAiDone(true);
      setAiRunning(false);
      return;
    }
    const timer = setTimeout(() => setAiStep(s => s + 1), 800);
    return () => clearTimeout(timer);
  }, [aiRunning, aiStep]);

  const handleAddVehicle = () => {
    if (!vehicleName || !driverName || !vehicleType) return;
    setVehicles(prev => [...prev, {
      id: `V${prev.length + 1}`,
      name: vehicleName,
      driver: driverName,
      type: vehicleType,
      status: "available",
      location: t("جراج المصنع", "Factory Garage"),
    }]);
    setAddDone(true);
    setTimeout(() => {
      setAddDone(false);
      setAddVehicleOpen(false);
      setVehicleName(""); setDriverName(""); setVehicleType("");
    }, 1400);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "available": return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t("متاح", "Available")}</Badge>;
      case "loading": return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20">{t("جاري التحميل", "Loading")}</Badge>;
      case "on-route": return <Badge className="bg-primary/10 text-primary border-primary/20">{t("في الطريق", "On Route")}</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الأسطول", "Fleet")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة الشاحنات والتوجيه الذكي للمسارات", "Fleet management and AI route optimization")}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setAddVehicleOpen(true)} data-testid="button-add-vehicle">
            <Plus className="w-4 h-4" />{t("إضافة مركبة", "Add Vehicle")}
          </Button>
          <Button className="gap-2" onClick={() => { setAiOpen(true); setAiStep(0); setAiDone(false); setAiRunning(false); }} data-testid="button-ai-route-optimize">
            <Navigation className="w-4 h-4" />
            {t("تحسين مسارات (AI)", "Optimize Routes (AI)")}
          </Button>
        </div>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vehicles.map((vehicle) => (
          <motion.div variants={itemVariants} key={vehicle.id}>
            <Card
              className="p-6 relative overflow-hidden group cursor-pointer hover:shadow-lg transition-shadow"
              data-testid={`card-vehicle-${vehicle.id}`}
              onClick={() => { setSelectedVehicle(vehicle); setVehicleDetailOpen(true); }}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-primary/10 text-primary rounded-lg">
                    <Truck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{vehicle.name}</h3>
                    <p className="text-xs text-muted-foreground">{vehicle.driver}</p>
                  </div>
                </div>
                {getStatusBadge(vehicle.status)}
              </div>
              <div className="mt-4 p-3 bg-muted/40 rounded-lg flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 text-primary" />
                {vehicle.location}
              </div>
              <p className="text-xs text-primary mt-3 opacity-0 group-hover:opacity-100 transition-opacity">{t("انقر لعرض التفاصيل", "Click for details")}</p>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* AI Route Optimization Dialog */}
      <Dialog open={aiOpen} onOpenChange={setAiOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-primary" />
              {t("تحسين المسارات بالذكاء الاصطناعي", "AI Route Optimization")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {!aiRunning && !aiDone && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <p className="text-sm text-muted-foreground">{t("سيقوم الذكاء الاصطناعي بتحليل طلبات التسليم المعلقة واقتراح أفضل مسار لكل سيارة.", "AI will analyze pending delivery orders and suggest the optimal route for each vehicle.")}</p>
                <div className="p-4 bg-muted/30 rounded-lg space-y-2">
                  <p className="text-sm font-medium">{t("الطلبات المعلقة: 5 طلبات", "Pending Orders: 5 orders")}</p>
                  <p className="text-sm font-medium">{t("السيارات المتاحة: 2", "Available Vehicles: 2")}</p>
                  <p className="text-sm font-medium">{t("المناطق: الدلتا والصعيد", "Areas: Delta and Upper Egypt")}</p>
                </div>
                <Button className="w-full gap-2" onClick={runAi} data-testid="button-run-ai-optimization">
                  <Cpu className="w-4 h-4" />{t("بدء التحليل", "Start Analysis")}
                </Button>
              </motion.div>
            )}

            {(aiRunning || (aiDone && aiStep > 0)) && !aiDone && (
              <div className="space-y-4">
                <div className="flex items-center justify-center py-6">
                  <div className="relative w-20 h-20">
                    <motion.div
                      className="absolute inset-0 rounded-full border-4 border-primary/20"
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    />
                    <motion.div
                      className="absolute inset-0 rounded-full border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Cpu className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  {aiSteps.slice(0, aiStep + 1).map((step, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className={`w-4 h-4 ${i < aiStep ? "text-emerald-500" : "text-primary"}`} />
                      <span className={i < aiStep ? "text-muted-foreground" : "text-foreground font-medium"}>{step}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {aiDone && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                <div className="flex items-center gap-2 text-emerald-500 font-medium">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>{t("اكتمل التحسين! إليك أفضل المسارات:", "Optimization complete! Here are the best routes:")}</span>
                </div>
                {suggestedRoutes.map((route, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.15 }} className="rounded-lg border border-border bg-muted/20 p-4 space-y-3">
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      <Truck className="w-4 h-4 text-primary" />{route.vehicle}
                    </div>
                    <p className="text-xs text-muted-foreground flex items-center gap-1"><User className="w-3 h-3" />{route.driver}</p>
                    <div className="space-y-1">
                      {route.stops.map((stop, j) => (
                        <div key={j} className="flex items-center gap-2 text-xs">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                          <span>{stop}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-4 text-xs text-muted-foreground pt-1 border-t border-border">
                      <span className="flex items-center gap-1"><Route className="w-3 h-3" />{route.distance}</span>
                      <span>{t("الوقت:", "ETA:")} {route.eta}</span>
                    </div>
                  </motion.div>
                ))}
                <Button className="w-full gap-2" onClick={() => setAiOpen(false)} data-testid="button-confirm-routes">
                  <CheckCircle2 className="w-4 h-4" />{t("تأكيد وتعيين المسارات", "Confirm & Assign Routes")}
                </Button>
              </motion.div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Vehicle Sheet */}
      <Sheet open={addVehicleOpen} onOpenChange={setAddVehicleOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إضافة مركبة جديدة", "Add New Vehicle")}</SheetTitle>
            <SheetDescription>{t("أدخل بيانات المركبة والسائق", "Enter vehicle and driver details")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("رقم / اسم المركبة", "Vehicle Name / Plate")}</Label>
              <Input placeholder={t("مثال: نقل ثقيل - ع ن 9999", "e.g. Heavy Truck - EGP 9999")} value={vehicleName} onChange={e => setVehicleName(e.target.value)} data-testid="input-vehicle-name" />
            </div>
            <div className="space-y-2">
              <Label>{t("اسم السائق", "Driver Name")}</Label>
              <Input placeholder={t("اسم السائق", "Driver name")} value={driverName} onChange={e => setDriverName(e.target.value)} data-testid="input-driver-name" />
            </div>
            <div className="space-y-2">
              <Label>{t("نوع المركبة", "Vehicle Type")}</Label>
              <Select value={vehicleType} onValueChange={setVehicleType}>
                <SelectTrigger data-testid="select-vehicle-type"><SelectValue placeholder={t("اختر النوع", "Select type")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="heavy">{t("نقل ثقيل", "Heavy Truck")}</SelectItem>
                  <SelectItem value="semi">{t("نصف نقل", "Semi Truck")}</SelectItem>
                  <SelectItem value="quarter">{t("ربع نقل", "Quarter Truck")}</SelectItem>
                  <SelectItem value="light">{t("نقل خفيف", "Light Truck")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <AnimatePresence mode="wait">
              {addDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم الإضافة!", "Added!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleAddVehicle} disabled={!vehicleName || !driverName || !vehicleType} data-testid="button-submit-vehicle">
                    {t("إضافة المركبة", "Add Vehicle")}
                  </Button>
                  <Button variant="outline" onClick={() => setAddVehicleOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Vehicle Detail Dialog */}
      <Dialog open={vehicleDetailOpen} onOpenChange={setVehicleDetailOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("تفاصيل المركبة", "Vehicle Details")}</DialogTitle>
          </DialogHeader>
          {selectedVehicle && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <div className="p-3 bg-primary/10 text-primary rounded-lg"><Truck className="w-8 h-8" /></div>
                <div>
                  <p className="font-bold text-lg">{selectedVehicle.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedVehicle.type}</p>
                </div>
                {getStatusBadge(selectedVehicle.status)}
              </div>
              {[
                [<User className="w-4 h-4" />, t("السائق", "Driver"), selectedVehicle.driver],
                [<MapPin className="w-4 h-4" />, t("الموقع الحالي", "Current Location"), selectedVehicle.location],
              ].map(([icon, label, val]: any) => (
                <div key={label} className="flex items-center justify-between py-3 border-b border-border">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm">{icon}{label}</div>
                  <span className="font-medium text-sm">{val}</span>
                </div>
              ))}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <Button variant="outline" className="gap-2">
                  <Package className="w-4 h-4" />{t("تحميل شحنة", "Load Shipment")}
                </Button>
                <Button variant="outline" className="gap-2">
                  <Phone className="w-4 h-4" />{t("اتصال بالسائق", "Call Driver")}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
