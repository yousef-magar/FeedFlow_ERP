import React, { useState } from "react";
import { useAppStore, DEFAULT_SIDEBAR_ORDER } from "@/hooks/use-app-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Settings as SettingsIcon,
  Building,
  Shield,
  Database,
  Save,
  LayoutList,
  GripVertical,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  LayoutDashboard,
  Factory,
  Package,
  ShoppingCart,
  Users,
  Truck,
  UserCircle,
  Banknote,
  Briefcase,
  Calculator,
  FileText,
  BarChart,
  BotMessageSquare,
  UserCog,
  LucideIcon,
} from "lucide-react";

const MODULE_ICON_MAP: Record<string, LucideIcon> = {
  "/": LayoutDashboard,
  "/production": Factory,
  "/inventory": Package,
  "/sales": ShoppingCart,
  "/customers": Users,
  "/fleet": Truck,
  "/hr": UserCircle,
  "/payroll": Banknote,
  "/marketing": Briefcase,
  "/accounting": Calculator,
  "/procurement": FileText,
  "/reports": BarChart,
  "/ai-assistant": BotMessageSquare,
  "/sub-accounts": UserCog,
  "/settings": SettingsIcon,
};

const MODULE_LABELS: Record<string, { ar: string; en: string }> = {
  "/": { ar: "الرئيسية", en: "Dashboard" },
  "/production": { ar: "الإنتاج", en: "Production" },
  "/inventory": { ar: "المخزون", en: "Inventory" },
  "/sales": { ar: "المبيعات", en: "Sales" },
  "/customers": { ar: "العملاء", en: "Customers" },
  "/fleet": { ar: "الأسطول", en: "Fleet & Delivery" },
  "/hr": { ar: "الموارد البشرية", en: "HR" },
  "/payroll": { ar: "الرواتب", en: "Payroll" },
  "/marketing": { ar: "التسويق", en: "Marketing" },
  "/accounting": { ar: "الحسابات", en: "Accounting" },
  "/procurement": { ar: "المشتريات", en: "Procurement" },
  "/reports": { ar: "التقارير", en: "Reports" },
  "/ai-assistant": { ar: "المساعد الذكي", en: "AI Assistant" },
  "/sub-accounts": { ar: "الحسابات الفرعية", en: "Sub Accounts" },
  "/settings": { ar: "الإعدادات", en: "Settings" },
};

export default function Settings() {
  const { t, sidebarOrder, setSidebarOrder } = useAppStore();
  const [localOrder, setLocalOrder] = useState<string[]>(sidebarOrder);
  const [saved, setSaved] = useState(false);

  const moveItem = (index: number, direction: "up" | "down") => {
    const newOrder = [...localOrder];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newOrder.length) return;
    [newOrder[index], newOrder[targetIndex]] = [newOrder[targetIndex], newOrder[index]];
    setLocalOrder(newOrder);
    setSaved(false);
  };

  const handleSave = () => {
    setSidebarOrder(localOrder);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => {
    setLocalOrder([...DEFAULT_SIDEBAR_ORDER]);
    setSaved(false);
  };

  const isDirty = JSON.stringify(localOrder) !== JSON.stringify(sidebarOrder);

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الإعدادات", "Settings")}</h1>
          <p className="text-muted-foreground mt-1">{t("إعدادات النظام والشركة", "System and company configuration")}</p>
        </div>
        <Button className="gap-2" onClick={handleSave}>
          <Save className="w-4 h-4" />
          {saved ? t("تم الحفظ ✓", "Saved ✓") : t("حفظ التغييرات", "Save Changes")}
        </Button>
      </div>

      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6 border-b border-border pb-4">
          <Building className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold">{t("بيانات الشركة", "Company Details")}</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>{t("اسم الشركة", "Company Name")}</Label>
            <div className="p-2 border border-border rounded-md bg-muted/50 text-sm">مصنع الوطنية للأعلاف</div>
          </div>
          <div className="space-y-2">
            <Label>{t("العنوان", "Address")}</Label>
            <div className="p-2 border border-border rounded-md bg-muted/50 text-sm">المنطقة الصناعية</div>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6 border-b border-border pb-4">
          <SettingsIcon className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold">{t("الوحدات الفعالة", "Active Modules")}</h2>
        </div>
        
        <div className="space-y-4">
          {[
            { id: 'prod', name: 'الإنتاج (Production)' },
            { id: 'inv', name: 'المخزون (Inventory)' },
            { id: 'sales', name: 'المبيعات (Sales)' },
            { id: 'hr', name: 'الموارد البشرية (HR)' },
            { id: 'fleet', name: 'الأسطول (Fleet)' },
          ].map((mod) => (
            <div key={mod.id} className="flex items-center justify-between p-3 border border-border rounded-lg bg-card">
              <Label htmlFor={mod.id} className="cursor-pointer">{mod.name}</Label>
              <Switch id={mod.id} defaultChecked />
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6 border-b border-border pb-4">
          <div className="flex items-center gap-3">
            <LayoutList className="w-5 h-5 text-primary" />
            <div>
              <h2 className="text-lg font-bold">{t("ترتيب القائمة الجانبية", "Sidebar Order")}</h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                {t("اضغط على الأسهم لإعادة ترتيب العناصر", "Use the arrows to reorder items")}
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={handleReset}>
            <RotateCcw className="w-3.5 h-3.5" />
            {t("استعادة الافتراضي", "Reset Default")}
          </Button>
        </div>

        <div className="space-y-2">
          {localOrder.map((path, index) => {
            const label = MODULE_LABELS[path];
            const Icon = MODULE_ICON_MAP[path];
            if (!label || !Icon) return null;
            return (
              <div
                key={path}
                className="flex items-center gap-3 p-3 border border-border rounded-lg bg-card hover:bg-muted/30 transition-colors group"
              >
                <GripVertical className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />
                <div className="w-7 h-7 rounded bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <span className="flex-1 text-sm font-medium">{t(label.ar, label.en)}</span>
                <span className="text-xs text-muted-foreground/50 tabular-nums w-5 text-center">{index + 1}</span>
                <div className="flex flex-col gap-0.5">
                  <button
                    onClick={() => moveItem(index, "up")}
                    disabled={index === 0}
                    className="w-6 h-5 flex items-center justify-center rounded hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => moveItem(index, "down")}
                    disabled={index === localOrder.length - 1}
                    className="w-6 h-5 flex items-center justify-center rounded hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {isDirty && (
          <div className="mt-4 flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
            <p className="text-sm text-primary">{t("يوجد تغييرات غير محفوظة", "You have unsaved changes")}</p>
            <Button size="sm" onClick={handleSave} className="gap-1.5 h-7 text-xs">
              <Save className="w-3 h-3" />
              {t("حفظ الآن", "Save Now")}
            </Button>
          </div>
        )}
      </Card>
      
      <Card className="p-6 border-destructive/20">
        <div className="flex items-center gap-3 mb-6 border-b border-destructive/20 pb-4">
          <Shield className="w-5 h-5 text-destructive" />
          <h2 className="text-lg font-bold text-destructive">{t("الأمان والنسخ الاحتياطي", "Security & Backup")}</h2>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="gap-2">
            <Database className="w-4 h-4" />
            {t("نسخة احتياطية الآن", "Backup Now")}
          </Button>
        </div>
      </Card>
    </div>
  );
}
