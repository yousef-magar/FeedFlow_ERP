import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { UserCircle, UserPlus, FileText, CheckCircle2, Phone, Mail, Calendar, DollarSign, Clock } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const departments = ["الإنتاج", "المبيعات", "الحسابات", "المخازن", "الأسطول", "الموارد البشرية", "الإدارة"];

export default function HR() {
  const { t } = useAppStore();
  const [addOpen, setAddOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [leaveOpen, setLeaveOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);
  const [leaveSubmitted, setLeaveSubmitted] = useState(false);

  const [employees, setEmployees] = useState(mockData.employees);

  // Add form
  const [empName, setEmpName] = useState("");
  const [empDept, setEmpDept] = useState("");
  const [empPosition, setEmpPosition] = useState("");
  const [empSalary, setEmpSalary] = useState("");
  const [empPhone, setEmpPhone] = useState("");

  // Leave form
  const [leaveType, setLeaveType] = useState("");
  const [leaveFrom, setLeaveFrom] = useState("");
  const [leaveTo, setLeaveTo] = useState("");
  const [leaveReason, setLeaveReason] = useState("");

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleAddEmployee = () => {
    if (!empName || !empDept || !empPosition || !empSalary) return;
    setEmployees(prev => [...prev, {
      id: `E${prev.length + 1}`,
      name: empName,
      department: empDept,
      position: empPosition,
      baseSalary: parseFloat(empSalary),
      status: "present",
      allowances: 0,
      overtime: 0,
      deductions: 0,
      advances: 0,
    }]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false); setAddOpen(false);
      setEmpName(""); setEmpDept(""); setEmpPosition(""); setEmpSalary(""); setEmpPhone("");
    }, 1400);
  };

  const handleLeaveSubmit = () => {
    if (!leaveType || !leaveFrom || !leaveTo) return;
    setLeaveSubmitted(true);
    setTimeout(() => {
      setLeaveSubmitted(false); setLeaveOpen(false);
      setLeaveType(""); setLeaveFrom(""); setLeaveTo(""); setLeaveReason("");
    }, 1400);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present": return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t("حاضر", "Present")}</Badge>;
      case "absent": return <Badge className="bg-destructive/10 text-destructive border-destructive/20">{t("غائب", "Absent")}</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الموارد البشرية", "HR")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة الموظفين والحضور والانصراف", "Employee and attendance management")}</p>
        </div>
        <Button className="gap-2" onClick={() => setAddOpen(true)} data-testid="button-add-employee">
          <UserPlus className="w-4 h-4" />
          {t("إضافة موظف", "Add Employee")}
        </Button>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
              <tr>
                <th className="px-6 py-4">{t("الموظف", "Employee")}</th>
                <th className="px-6 py-4">{t("القسم", "Department")}</th>
                <th className="px-6 py-4">{t("الوظيفة", "Position")}</th>
                <th className="px-6 py-4">{t("الراتب الأساسي", "Base Salary")}</th>
                <th className="px-6 py-4">{t("الحالة", "Status")}</th>
                <th className="px-6 py-4 text-center">{t("إجراءات", "Actions")}</th>
              </tr>
            </thead>
            <motion.tbody variants={containerVariants} initial="hidden" animate="show">
              <AnimatePresence>
                {employees.map((emp) => (
                  <motion.tr variants={itemVariants} key={emp.id} layout className="border-b border-border hover:bg-muted/30 transition-colors" data-testid={`row-employee-${emp.id}`}>
                    <td className="px-6 py-4 font-medium">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                          {emp.name.substring(0, 1)}
                        </div>
                        {emp.name}
                      </div>
                    </td>
                    <td className="px-6 py-4">{emp.department}</td>
                    <td className="px-6 py-4">{emp.position}</td>
                    <td className="px-6 py-4 font-semibold">{formatCurrency(emp.baseSalary)}</td>
                    <td className="px-6 py-4">{getStatusBadge(emp.status)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" data-testid={`button-view-employee-${emp.id}`} onClick={() => { setSelectedEmployee(emp); setProfileOpen(true); }}>
                          <FileText className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 text-xs text-amber-500 hover:bg-amber-500/10 hover:text-amber-500" data-testid={`button-leave-employee-${emp.id}`} onClick={() => { setSelectedEmployee(emp); setLeaveOpen(true); }}>
                          <Calendar className="w-3 h-3 mx-1" />{t("إجازة", "Leave")}
                        </Button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </motion.tbody>
          </table>
        </div>
      </Card>

      {/* Add Employee Sheet */}
      <Sheet open={addOpen} onOpenChange={setAddOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إضافة موظف جديد", "Add New Employee")}</SheetTitle>
            <SheetDescription>{t("أدخل بيانات الموظف الجديد", "Enter new employee details")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("الاسم الكامل", "Full Name")}</Label>
              <Input placeholder={t("اسم الموظف", "Employee name")} value={empName} onChange={e => setEmpName(e.target.value)} data-testid="input-employee-name" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("القسم", "Department")}</Label>
                <Select value={empDept} onValueChange={setEmpDept}>
                  <SelectTrigger data-testid="select-employee-dept"><SelectValue placeholder={t("اختر القسم", "Select dept")} /></SelectTrigger>
                  <SelectContent>
                    {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("المسمى الوظيفي", "Job Title")}</Label>
                <Input placeholder={t("المسمى الوظيفي", "Job title")} value={empPosition} onChange={e => setEmpPosition(e.target.value)} data-testid="input-employee-position" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("الراتب الأساسي (ج.م)", "Base Salary (EGP)")}</Label>
                <Input type="number" min="0" placeholder="0" value={empSalary} onChange={e => setEmpSalary(e.target.value)} data-testid="input-employee-salary" />
              </div>
              <div className="space-y-2">
                <Label>{t("رقم الهاتف", "Phone")}</Label>
                <Input placeholder="01XXXXXXXXX" value={empPhone} onChange={e => setEmpPhone(e.target.value)} dir="ltr" data-testid="input-employee-phone" />
              </div>
            </div>
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم إضافة الموظف!", "Employee added!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleAddEmployee} disabled={!empName || !empDept || !empPosition || !empSalary} data-testid="button-submit-employee">
                    {t("إضافة الموظف", "Add Employee")}
                  </Button>
                  <Button variant="outline" onClick={() => setAddOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Employee Profile Sheet */}
      <Sheet open={profileOpen} onOpenChange={setProfileOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          {selectedEmployee && (
            <>
              <SheetHeader className="mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-2xl">
                    {selectedEmployee.name.substring(0, 1)}
                  </div>
                  <div>
                    <SheetTitle className="text-xl">{selectedEmployee.name}</SheetTitle>
                    <p className="text-sm text-muted-foreground mt-1">{selectedEmployee.position} — {selectedEmployee.department}</p>
                    {getStatusBadge(selectedEmployee.status)}
                  </div>
                </div>
              </SheetHeader>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {[
                  { icon: DollarSign, label: t("الراتب الأساسي", "Base Salary"), value: formatCurrency(selectedEmployee.baseSalary), color: "text-primary" },
                  { icon: DollarSign, label: t("البدلات", "Allowances"), value: formatCurrency(selectedEmployee.allowances), color: "text-emerald-500" },
                  { icon: Clock, label: t("العمل الإضافي", "Overtime"), value: formatCurrency(selectedEmployee.overtime), color: "text-emerald-500" },
                  { icon: DollarSign, label: t("السلف", "Advances"), value: formatCurrency(selectedEmployee.advances), color: selectedEmployee.advances > 0 ? "text-destructive" : "text-foreground" },
                ].map(({ icon: Icon, label, value, color }) => (
                  <Card key={label} className="p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{label}</span>
                    </div>
                    <p className={`font-bold text-sm ${color}`}>{value}</p>
                  </Card>
                ))}
              </div>

              <Card className="p-4 mb-6">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">{t("صافي الراتب", "Net Salary")}</span>
                  <span className="text-xl font-bold text-primary">
                    {formatCurrency(selectedEmployee.baseSalary + selectedEmployee.allowances + selectedEmployee.overtime - selectedEmployee.deductions - selectedEmployee.advances)}
                  </span>
                </div>
              </Card>

              <div className="grid grid-cols-2 gap-2">
                <Button className="gap-2" onClick={() => { setProfileOpen(false); setLeaveOpen(true); }} data-testid="button-request-leave-from-profile">
                  <Calendar className="w-4 h-4" />{t("طلب إجازة", "Request Leave")}
                </Button>
                <Button variant="outline" className="gap-2" data-testid="button-advance-from-profile">
                  <DollarSign className="w-4 h-4" />{t("طلب سلفة", "Request Advance")}
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Leave Request Sheet */}
      <Sheet open={leaveOpen} onOpenChange={setLeaveOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("طلب إجازة", "Leave Request")}</SheetTitle>
            {selectedEmployee && <SheetDescription>{selectedEmployee.name}</SheetDescription>}
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("نوع الإجازة", "Leave Type")}</Label>
              <Select value={leaveType} onValueChange={setLeaveType}>
                <SelectTrigger data-testid="select-leave-type"><SelectValue placeholder={t("اختر النوع", "Select type")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">{t("اعتيادية", "Annual")}</SelectItem>
                  <SelectItem value="sick">{t("مرضية", "Sick")}</SelectItem>
                  <SelectItem value="unpaid">{t("بدون راتب", "Unpaid")}</SelectItem>
                  <SelectItem value="emergency">{t("طارئة", "Emergency")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("من تاريخ", "From Date")}</Label>
                <Input type="date" value={leaveFrom} onChange={e => setLeaveFrom(e.target.value)} data-testid="input-leave-from" />
              </div>
              <div className="space-y-2">
                <Label>{t("إلى تاريخ", "To Date")}</Label>
                <Input type="date" value={leaveTo} onChange={e => setLeaveTo(e.target.value)} data-testid="input-leave-to" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("سبب الإجازة", "Reason")}</Label>
              <Input placeholder={t("سبب الإجازة...", "Leave reason...")} value={leaveReason} onChange={e => setLeaveReason(e.target.value)} data-testid="input-leave-reason" />
            </div>
            <AnimatePresence mode="wait">
              {leaveSubmitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم إرسال طلب الإجازة!", "Leave request submitted!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleLeaveSubmit} disabled={!leaveType || !leaveFrom || !leaveTo} data-testid="button-submit-leave">
                    {t("إرسال الطلب", "Submit Request")}
                  </Button>
                  <Button variant="outline" onClick={() => setLeaveOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
