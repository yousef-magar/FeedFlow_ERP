import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { motion, AnimatePresence } from "framer-motion";
import { FileText, CheckCircle2, Plus, DollarSign, Download } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

export default function Payroll() {
  const { t } = useAppStore();
  const [approveOpen, setApproveOpen] = useState(false);
  const [advanceOpen, setAdvanceOpen] = useState(false);
  const [approving, setApproving] = useState(false);
  const [approveDone, setApproveDone] = useState(false);
  const [selectedEmp, setSelectedEmp] = useState<any>(null);
  const [advanceAmount, setAdvanceAmount] = useState("");
  const [advanceDone, setAdvanceDone] = useState(false);

  const [employees, setEmployees] = useState(mockData.employees);

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const totalNetPayroll = employees.reduce((s, e) => s + e.baseSalary + e.allowances + e.overtime - e.deductions - e.advances, 0);

  const handleApprove = () => {
    setApproving(true);
    setTimeout(() => {
      setApproving(false);
      setApproveDone(true);
    }, 2200);
  };

  const handleAdvance = () => {
    if (!advanceAmount || !selectedEmp) return;
    setEmployees(prev => prev.map(e => e.id === selectedEmp.id ? { ...e, advances: e.advances + parseFloat(advanceAmount) } : e));
    setAdvanceDone(true);
    setTimeout(() => {
      setAdvanceDone(false); setAdvanceOpen(false);
      setAdvanceAmount(""); setSelectedEmp(null);
    }, 1400);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الرواتب", "Payroll")}</h1>
          <p className="text-muted-foreground mt-1">{t("معالجة واعتماد رواتب الموظفين", "Process and approve employee payroll")}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setAdvanceOpen(true)} data-testid="button-new-advance">
            <Plus className="w-4 h-4" />{t("سلفة جديدة", "New Advance")}
          </Button>
          <Button className="gap-2" onClick={() => { setApproveOpen(true); setApproveDone(false); setApproving(false); }} data-testid="button-approve-payroll">
            <CheckCircle2 className="w-4 h-4" />
            {t("اعتماد الرواتب", "Approve Payroll")}
          </Button>
        </div>
      </div>

      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-5 border-l-4 border-l-primary">
          <p className="text-sm text-muted-foreground mb-1">{t("إجمالي الرواتب", "Total Payroll")}</p>
          <p className="text-2xl font-bold text-primary">{formatCurrency(totalNetPayroll)}</p>
        </Card>
        <Card className="p-5 border-l-4 border-l-emerald-500">
          <p className="text-sm text-muted-foreground mb-1">{t("عدد الموظفين", "Employees Count")}</p>
          <p className="text-2xl font-bold text-emerald-500">{employees.length}</p>
        </Card>
        <Card className="p-5 border-l-4 border-l-amber-500">
          <p className="text-sm text-muted-foreground mb-1">{t("إجمالي السلف", "Total Advances")}</p>
          <p className="text-2xl font-bold text-amber-500">{formatCurrency(employees.reduce((s, e) => s + e.advances, 0))}</p>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
              <tr>
                <th className="px-6 py-4">{t("الموظف", "Employee")}</th>
                <th className="px-6 py-4">{t("الراتب الأساسي", "Base Salary")}</th>
                <th className="px-6 py-4 text-emerald-500">{t("بدلات ومكافآت", "Allowances")}</th>
                <th className="px-6 py-4 text-emerald-500">{t("إضافي", "Overtime")}</th>
                <th className="px-6 py-4 text-destructive">{t("خصومات", "Deductions")}</th>
                <th className="px-6 py-4 text-destructive">{t("سلف", "Advances")}</th>
                <th className="px-6 py-4 font-bold">{t("الصافي", "Net Pay")}</th>
                <th className="px-6 py-4 text-center">{t("إجراءات", "Actions")}</th>
              </tr>
            </thead>
            <motion.tbody variants={containerVariants} initial="hidden" animate="show">
              {employees.map((emp) => {
                const net = emp.baseSalary + emp.allowances + emp.overtime - emp.deductions - emp.advances;
                return (
                  <motion.tr variants={itemVariants} key={emp.id} className="border-b border-border hover:bg-muted/30 transition-colors" data-testid={`row-payroll-${emp.id}`}>
                    <td className="px-6 py-4 font-medium">{emp.name}</td>
                    <td className="px-6 py-4">{formatCurrency(emp.baseSalary)}</td>
                    <td className="px-6 py-4 text-emerald-500">+{formatCurrency(emp.allowances)}</td>
                    <td className="px-6 py-4 text-emerald-500">+{formatCurrency(emp.overtime)}</td>
                    <td className="px-6 py-4 text-destructive">-{formatCurrency(emp.deductions)}</td>
                    <td className="px-6 py-4 text-destructive">-{formatCurrency(emp.advances)}</td>
                    <td className="px-6 py-4 font-bold text-primary">{formatCurrency(net)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-1">
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-amber-500 hover:bg-amber-500/10" onClick={() => { setSelectedEmp(emp); setAdvanceOpen(true); }} data-testid={`button-advance-${emp.id}`}>
                          <DollarSign className="w-3 h-3" />{t("سلفة", "Advance")}
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" data-testid={`button-payslip-${emp.id}`}>
                          <FileText className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </motion.tbody>
          </table>
        </div>
      </Card>

      {/* Approve Payroll Dialog */}
      <Dialog open={approveOpen} onOpenChange={v => { if (!approving) setApproveOpen(v); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("اعتماد الرواتب", "Approve Payroll")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {!approving && !approveDone && (
              <>
                <div className="p-4 bg-muted/30 rounded-lg space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{t("عدد الموظفين", "Employees")}</span>
                    <span className="font-semibold">{employees.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{t("إجمالي الصرف", "Total Payout")}</span>
                    <span className="font-bold text-primary">{formatCurrency(totalNetPayroll)}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">{t("هل أنت متأكد من اعتماد وصرف رواتب هذا الشهر؟", "Are you sure you want to approve and disburse this month's payroll?")}</p>
                <div className="flex gap-3">
                  <Button className="flex-1" onClick={handleApprove} data-testid="button-confirm-approve-payroll">
                    {t("اعتماد وصرف", "Approve & Disburse")}
                  </Button>
                  <Button variant="outline" onClick={() => setApproveOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </div>
              </>
            )}

            {approving && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-8 flex flex-col items-center gap-4">
                <div className="relative w-16 h-16">
                  <motion.div className="absolute inset-0 rounded-full border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent"
                    animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <p className="text-sm font-medium text-muted-foreground">{t("جاري معالجة الرواتب...", "Processing payroll...")}</p>
              </motion.div>
            )}

            {approveDone && (
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="py-6 flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                </div>
                <p className="font-semibold text-emerald-500">{t("تم صرف الرواتب بنجاح!", "Payroll disbursed successfully!")}</p>
                <div className="flex gap-2">
                  <Button variant="outline" className="gap-2"><Download className="w-4 h-4" />{t("تحميل التقرير", "Export Report")}</Button>
                  <Button onClick={() => setApproveOpen(false)}>{t("إغلاق", "Close")}</Button>
                </div>
              </motion.div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Advance Sheet */}
      <Sheet open={advanceOpen} onOpenChange={setAdvanceOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("طلب سلفة", "Salary Advance")}</SheetTitle>
            <SheetDescription>{selectedEmp ? selectedEmp.name : t("اختر موظفاً", "Select employee")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("قيمة السلفة (ج.م)", "Advance Amount (EGP)")}</Label>
              <Input type="number" min="0" placeholder="0" value={advanceAmount} onChange={e => setAdvanceAmount(e.target.value)} data-testid="input-advance-amount" />
            </div>
            {selectedEmp && advanceAmount && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-3 bg-muted/30 rounded-lg text-sm">
                <p className="text-muted-foreground">{t("الراتب الأساسي:", "Base salary:")} <span className="font-semibold">{formatCurrency(selectedEmp.baseSalary)}</span></p>
                <p className="text-muted-foreground">{t("السلفة:", "Advance:")} <span className="font-semibold text-destructive">-{formatCurrency(parseFloat(advanceAmount) || 0)}</span></p>
                <p className="mt-1 font-bold">{t("الصافي:", "Net:")} <span className="text-primary">{formatCurrency(selectedEmp.baseSalary - (parseFloat(advanceAmount) || 0))}</span></p>
              </motion.div>
            )}
            <AnimatePresence mode="wait">
              {advanceDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تمت إضافة السلفة!", "Advance recorded!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleAdvance} disabled={!advanceAmount} data-testid="button-submit-advance">
                    {t("تأكيد السلفة", "Confirm Advance")}
                  </Button>
                  <Button variant="outline" onClick={() => setAdvanceOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
