import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Briefcase, Target, Trophy, Plus, CheckCircle2, Users, TrendingUp, DollarSign } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

export default function Marketing() {
  const { t } = useAppStore();
  const [addOpen, setAddOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [commissionOpen, setCommissionOpen] = useState(false);
  const [selectedMarketer, setSelectedMarketer] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);
  const [commissionDone, setCommissionDone] = useState(false);

  const [marketers, setMarketers] = useState(mockData.marketers);

  // Add form
  const [mName, setMName] = useState("");
  const [mRegion, setMRegion] = useState("");
  const [mCommType, setMCommType] = useState("");
  const [mCommRate, setMCommRate] = useState("");
  const [mTarget, setMTarget] = useState("");

  // Commission payout form
  const [payoutMethod, setPayoutMethod] = useState("");

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleAdd = () => {
    if (!mName || !mRegion || !mCommType) return;
    setMarketers(prev => [...prev, {
      id: `M${prev.length + 1}`,
      name: mName,
      region: mRegion,
      customersCount: 0,
      totalSales: 0,
      commission: 0,
      target: parseFloat(mTarget) || 1000000,
    }]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false); setAddOpen(false);
      setMName(""); setMRegion(""); setMCommType(""); setMCommRate(""); setMTarget("");
    }, 1400);
  };

  const handleCommissionPayout = () => {
    if (!payoutMethod) return;
    setCommissionDone(true);
    setTimeout(() => {
      setCommissionDone(false); setCommissionOpen(false);
      setPayoutMethod("");
    }, 1400);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("التسويق والعمولات", "Marketing")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة المناديب وعمولات المبيعات", "Manage marketers and sales commissions")}</p>
        </div>
        <Button className="gap-2" onClick={() => setAddOpen(true)} data-testid="button-add-marketer">
          <Plus className="w-4 h-4" />
          {t("إضافة مندوب", "Add Marketer")}
        </Button>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {marketers.map((m) => {
            const progress = Math.min(100, Math.round((m.totalSales / m.target) * 100));
            return (
              <motion.div variants={itemVariants} key={m.id} layout>
                <Card
                  className="p-6 relative overflow-hidden group cursor-pointer hover:shadow-lg transition-shadow"
                  data-testid={`card-marketer-${m.id}`}
                  onClick={() => { setSelectedMarketer(m); setDetailOpen(true); }}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-primary/10 text-primary rounded-lg">
                        <Briefcase className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground group-hover:text-primary transition-colors">{m.name}</h3>
                        <p className="text-xs text-muted-foreground">{m.region} — {m.customersCount} {t("عميل", "Customers")}</p>
                      </div>
                    </div>
                    {progress >= 100 && <Trophy className="w-5 h-5 text-amber-500" />}
                  </div>

                  <div className="space-y-4 mb-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">{t("المبيعات:", "Sales:")}</span>
                        <span className="font-semibold">{formatCurrency(m.totalSales)}</span>
                      </div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-muted-foreground">{t("الهدف:", "Target:")}</span>
                        <span>{formatCurrency(m.target)}</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                      <p className="text-xs text-left rtl:text-right mt-1 text-muted-foreground">{progress}%</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-border">
                    <div>
                      <p className="text-xs text-muted-foreground">{t("العمولة المستحقة", "Commission Due")}</p>
                      <p className="font-bold text-emerald-500">{formatCurrency(m.commission)}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs gap-1 text-emerald-500 border-emerald-500/40 hover:bg-emerald-500/10"
                      onClick={e => { e.stopPropagation(); setSelectedMarketer(m); setCommissionOpen(true); }}
                      data-testid={`button-pay-commission-${m.id}`}
                    >
                      <DollarSign className="w-3 h-3" />{t("صرف العمولة", "Pay Commission")}
                    </Button>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </motion.div>

      {/* Add Marketer Sheet */}
      <Sheet open={addOpen} onOpenChange={setAddOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إضافة مندوب جديد", "Add New Marketer")}</SheetTitle>
            <SheetDescription>{t("أدخل بيانات المندوب وطريقة احتساب العمولة", "Enter marketer details and commission structure")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("الاسم", "Name")}</Label>
                <Input placeholder={t("اسم المندوب", "Marketer name")} value={mName} onChange={e => setMName(e.target.value)} data-testid="input-marketer-name" />
              </div>
              <div className="space-y-2">
                <Label>{t("المنطقة", "Region")}</Label>
                <Input placeholder={t("مثال: الدلتا", "e.g. Delta")} value={mRegion} onChange={e => setMRegion(e.target.value)} data-testid="input-marketer-region" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("نوع العمولة", "Commission Type")}</Label>
              <Select value={mCommType} onValueChange={setMCommType}>
                <SelectTrigger data-testid="select-commission-type"><SelectValue placeholder={t("اختر نوع العمولة", "Select commission type")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pct">{t("نسبة من الفاتورة %", "% of Invoice")}</SelectItem>
                  <SelectItem value="per_ton">{t("مبلغ لكل طن", "Amount per Ton")}</SelectItem>
                  <SelectItem value="tiered">{t("نظام الشرائح", "Tiered System")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {mCommType === "pct" && (
              <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
                <Label>{t("النسبة %", "Rate %")}</Label>
                <Input type="number" min="0" max="100" placeholder="2" value={mCommRate} onChange={e => setMCommRate(e.target.value)} data-testid="input-commission-rate-pct" />
              </motion.div>
            )}
            {mCommType === "per_ton" && (
              <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
                <Label>{t("المبلغ لكل طن (ج.م)", "Amount per Ton (EGP)")}</Label>
                <Input type="number" min="0" placeholder="50" value={mCommRate} onChange={e => setMCommRate(e.target.value)} data-testid="input-commission-rate-ton" />
              </motion.div>
            )}
            {mCommType === "tiered" && (
              <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="p-3 bg-muted/30 rounded-lg text-sm space-y-1">
                <p className="font-medium mb-2">{t("نظام الشرائح التلقائي:", "Auto Tiered System:")}</p>
                <p>0 – 100 {t("طن", "tons")} = 1%</p>
                <p>100 – 300 {t("طن", "tons")} = 2%</p>
                <p>300+ {t("طن", "tons")} = 3%</p>
              </motion.div>
            )}
            <div className="space-y-2">
              <Label>{t("الهدف الشهري (ج.م)", "Monthly Target (EGP)")}</Label>
              <Input type="number" min="0" placeholder="1000000" value={mTarget} onChange={e => setMTarget(e.target.value)} data-testid="input-marketer-target" />
            </div>
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم إضافة المندوب!", "Marketer added!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleAdd} disabled={!mName || !mRegion || !mCommType} data-testid="button-submit-marketer">
                    {t("إضافة المندوب", "Add Marketer")}
                  </Button>
                  <Button variant="outline" onClick={() => setAddOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Marketer Detail Sheet */}
      <Sheet open={detailOpen} onOpenChange={setDetailOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          {selectedMarketer && (
            <>
              <SheetHeader className="mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xl">
                    {selectedMarketer.name.substring(0, 2)}
                  </div>
                  <div>
                    <SheetTitle className="text-xl">{selectedMarketer.name}</SheetTitle>
                    <p className="text-sm text-muted-foreground mt-1">{selectedMarketer.region}</p>
                  </div>
                </div>
              </SheetHeader>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {[
                  { icon: TrendingUp, label: t("إجمالي المبيعات", "Total Sales"), value: formatCurrency(selectedMarketer.totalSales), color: "text-primary" },
                  { icon: Target, label: t("الهدف الشهري", "Monthly Target"), value: formatCurrency(selectedMarketer.target), color: "text-foreground" },
                  { icon: DollarSign, label: t("العمولة المستحقة", "Commission Due"), value: formatCurrency(selectedMarketer.commission), color: "text-emerald-500" },
                  { icon: Users, label: t("عدد العملاء", "Customers Count"), value: `${selectedMarketer.customersCount} ${t("عميل", "clients")}`, color: "text-foreground" },
                ].map(({ icon: Icon, label, value, color }) => (
                  <Card key={label} className="p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="w-4 h-4 text-muted-foreground" /><span className="text-xs text-muted-foreground">{label}</span>
                    </div>
                    <p className={`font-bold text-sm ${color}`}>{value}</p>
                  </Card>
                ))}
              </div>

              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">{t("تحقيق الهدف", "Target Achievement")}</span>
                  <span className="font-bold">{Math.min(100, Math.round((selectedMarketer.totalSales / selectedMarketer.target) * 100))}%</span>
                </div>
                <Progress value={Math.min(100, Math.round((selectedMarketer.totalSales / selectedMarketer.target) * 100))} className="h-3" />
              </div>

              <Button
                className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={() => { setDetailOpen(false); setCommissionOpen(true); }}
                data-testid="button-pay-commission-from-detail"
              >
                <DollarSign className="w-4 h-4" />{t("صرف العمولة", "Pay Commission")}
              </Button>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Commission Payout Dialog */}
      <Sheet open={commissionOpen} onOpenChange={setCommissionOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("صرف العمولة", "Pay Commission")}</SheetTitle>
            {selectedMarketer && <SheetDescription>{selectedMarketer.name} — {formatCurrency(selectedMarketer.commission)}</SheetDescription>}
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("طريقة الصرف", "Payout Method")}</Label>
              <Select value={payoutMethod} onValueChange={setPayoutMethod}>
                <SelectTrigger data-testid="select-commission-payout-method"><SelectValue placeholder={t("اختر الطريقة", "Select method")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">{t("إضافة للخزنة اليومية", "Add to Daily Treasury")}</SelectItem>
                  <SelectItem value="weekly">{t("صرف أسبوعي", "Weekly Payout")}</SelectItem>
                  <SelectItem value="monthly">{t("إضافة للراتب الشهري", "Add to Monthly Salary")}</SelectItem>
                  <SelectItem value="bank">{t("تحويل بنكي", "Bank Transfer")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {selectedMarketer && payoutMethod && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                <p className="text-sm text-muted-foreground">{t("المبلغ المستحق للصرف:", "Amount to be paid:")}</p>
                <p className="text-2xl font-bold text-emerald-500 mt-1">{formatCurrency(selectedMarketer.commission)}</p>
              </motion.div>
            )}
            <AnimatePresence mode="wait">
              {commissionDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم صرف العمولة!", "Commission paid!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleCommissionPayout} disabled={!payoutMethod} data-testid="button-confirm-commission-payout">
                    {t("تأكيد الصرف", "Confirm Payout")}
                  </Button>
                  <Button variant="outline" onClick={() => setCommissionOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
