import React, { useState, useEffect, useRef } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  TrendingUp, DollarSign, Package, AlertTriangle, Users, Truck,
  ArrowUpRight, ArrowDownRight, Banknote, Factory, FileText, Download, CheckCircle2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar
} from "recharts";

const salesData = [
  { name: "السبت", value: 850000 }, { name: "الأحد", value: 920000 },
  { name: "الإثنين", value: 1100000 }, { name: "الثلاثاء", value: 1050000 },
  { name: "الأربعاء", value: 1250000 }, { name: "الخميس", value: 1450000 },
  { name: "الجمعة", value: 1800000 },
];

const productData = [
  { name: "نامي 21%", sales: 450, profit: 120 },
  { name: "بادي 23%", sales: 380, profit: 95 },
  { name: "حلاب 18%", sales: 290, profit: 70 },
  { name: "تسمين 16%", sales: 210, profit: 55 },
];

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } };

function AnimatedNumber({ target, prefix = "", suffix = "" }: { target: number; prefix?: string; suffix?: string }) {
  const [current, setCurrent] = useState(0);
  const frameRef = useRef<number>(0);
  useEffect(() => {
    const duration = 1200;
    const start = performance.now();
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCurrent(Math.round(eased * target));
      if (progress < 1) frameRef.current = requestAnimationFrame(animate);
    };
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [target]);
  return <>{prefix}{current.toLocaleString("ar-EG")}{suffix}</>;
}

export default function Dashboard() {
  const { t } = useAppStore();
  const { kpis, recentActivity } = mockData;
  const [reportOpen, setReportOpen] = useState(false);
  const [reportType, setReportType] = useState("");
  const [reportPeriod, setReportPeriod] = useState("");
  const [reportGenerated, setReportGenerated] = useState(false);
  const [generating, setGenerating] = useState(false);

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleGenerateReport = () => {
    if (!reportType || !reportPeriod) return;
    setGenerating(true);
    setTimeout(() => { setGenerating(false); setReportGenerated(true); }, 1800);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("لوحة القيادة", "Executive Dashboard")}</h1>
          <p className="text-muted-foreground mt-1">{t("نظرة عامة على أداء المصنع اليوم", "Overview of factory performance today")}</p>
        </div>
        <Button
          className="gap-2"
          onClick={() => { setReportOpen(true); setReportGenerated(false); setGenerating(false); setReportType(""); setReportPeriod(""); }}
          data-testid="button-new-report"
        >
          <FileText className="w-4 h-4" />
          {t("تقرير جديد", "New Report")}
        </Button>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title={t("مبيعات اليوم", "Today's Sales")}
          value={<AnimatedNumber target={kpis.todaySales} prefix="" suffix=" ج.م" />}
          icon={TrendingUp} trend="+12.5%" trendUp={true}
        />
        <KpiCard
          title={t("الأرباح", "Today's Profit")}
          value={<AnimatedNumber target={kpis.todayProfit} suffix=" ج.م" />}
          icon={DollarSign} trend="+8.2%" trendUp={true}
        />
        <KpiCard
          title={t("شحنات نشطة", "Active Shipments")}
          value={<AnimatedNumber target={kpis.activeShipments} />}
          icon={Truck}
        />
        <KpiCard
          title={t("عناصر مخزون حرجة", "Critical Inventory")}
          value={<AnimatedNumber target={kpis.criticalInventoryItems} />}
          icon={AlertTriangle} trend="-2" trendUp={false} alert
        />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-6">{t("تحليل المبيعات الأسبوعي", "Weekly Sales Trend")}</h3>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={salesData}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={v => `${v / 1000}k`} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", borderRadius: "8px" }} itemStyle={{ color: "hsl(var(--foreground))" }} />
                  <Area type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-6">{t("أداء المنتجات (بالطن)", "Product Performance (Tons)")}</h3>
            <div className="h-[240px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productData} layout="vertical" margin={{ left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis dataKey="name" type="category" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", borderRadius: "8px" }} cursor={{ fill: "hsl(var(--muted)/0.5)" }} />
                  <Bar dataKey="sales" name={t("المبيعات", "Sales")} fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={18} />
                  <Bar dataKey="profit" name={t("الربح", "Profit")} fill="hsl(var(--chart-2))" radius={[0, 4, 4, 0]} barSize={18} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="p-6 h-full flex flex-col">
            <h3 className="text-lg font-semibold mb-6">{t("النشاط الأخير", "Recent Activity")}</h3>
            <div className="flex-1 flex flex-col gap-6">
              {recentActivity.map((activity, i) => (
                <div key={activity.id} className="flex gap-4 relative">
                  {i !== recentActivity.length - 1 && (
                    <div className="absolute top-8 bottom-[-24px] right-4 rtl:right-4 ltr:left-4 w-px bg-border z-0" />
                  )}
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center z-10 shrink-0 border-2 border-card">
                    {activity.type === "production" && <Factory className="w-4 h-4 text-primary" />}
                    {activity.type === "finance" && <Banknote className="w-4 h-4 text-emerald-500" />}
                    {activity.type === "inventory" && <Package className="w-4 h-4 text-amber-500" />}
                    {activity.type === "fleet" && <Truck className="w-4 h-4 text-blue-500" />}
                    {activity.type === "sales" && <Users className="w-4 h-4 text-purple-500" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium leading-snug">{activity.action}</p>
                    <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* New Report Dialog */}
      <Dialog open={reportOpen} onOpenChange={v => { if (!generating) setReportOpen(v); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              {t("إنشاء تقرير جديد", "Generate New Report")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {!generating && !reportGenerated && (
              <>
                <div className="space-y-2">
                  <Label>{t("نوع التقرير", "Report Type")}</Label>
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger data-testid="select-report-type"><SelectValue placeholder={t("اختر نوع التقرير", "Select report type")} /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sales">{t("تقرير المبيعات", "Sales Report")}</SelectItem>
                      <SelectItem value="profit">{t("تقرير الأرباح", "Profit Report")}</SelectItem>
                      <SelectItem value="inventory">{t("تقرير المخزون", "Inventory Report")}</SelectItem>
                      <SelectItem value="hr">{t("تقرير الموارد البشرية", "HR Report")}</SelectItem>
                      <SelectItem value="fleet">{t("تقرير الأسطول", "Fleet Report")}</SelectItem>
                      <SelectItem value="executive">{t("ملخص تنفيذي", "Executive Summary")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>{t("الفترة الزمنية", "Time Period")}</Label>
                  <Select value={reportPeriod} onValueChange={setReportPeriod}>
                    <SelectTrigger data-testid="select-report-period"><SelectValue placeholder={t("اختر الفترة", "Select period")} /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">{t("اليوم", "Today")}</SelectItem>
                      <SelectItem value="week">{t("الأسبوع الحالي", "This Week")}</SelectItem>
                      <SelectItem value="month">{t("الشهر الحالي", "This Month")}</SelectItem>
                      <SelectItem value="quarter">{t("الربع الحالي", "This Quarter")}</SelectItem>
                      <SelectItem value="year">{t("السنة الحالية", "This Year")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-3 pt-2">
                  <Button className="flex-1 gap-2" onClick={handleGenerateReport} disabled={!reportType || !reportPeriod} data-testid="button-generate-report">
                    <FileText className="w-4 h-4" />{t("إنشاء التقرير", "Generate Report")}
                  </Button>
                  <Button variant="outline" onClick={() => setReportOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </div>
              </>
            )}

            {generating && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-8 flex flex-col items-center gap-4">
                <div className="relative w-16 h-16">
                  <motion.div className="absolute inset-0 rounded-full border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent"
                    animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <p className="text-sm font-medium text-muted-foreground">{t("جاري إنشاء التقرير...", "Generating report...")}</p>
              </motion.div>
            )}

            {reportGenerated && (
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="py-4 space-y-4">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/10 flex items-center justify-center">
                    <CheckCircle2 className="w-7 h-7 text-emerald-500" />
                  </div>
                  <p className="font-semibold text-emerald-500">{t("تم إنشاء التقرير!", "Report generated!")}</p>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button className="gap-2" data-testid="button-download-report">
                    <Download className="w-4 h-4" />{t("تحميل PDF", "Download PDF")}
                  </Button>
                  <Button variant="outline" onClick={() => setReportOpen(false)}>{t("إغلاق", "Close")}</Button>
                </div>
              </motion.div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function KpiCard({ title, value, icon: Icon, trend, trendUp, alert = false }: any) {
  const { t } = useAppStore();
  return (
    <motion.div variants={itemVariants}>
      <Card className={`p-6 relative overflow-hidden group ${alert ? "border-destructive/50 bg-destructive/5" : ""}`}>
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
            <h3 className="text-2xl font-bold tracking-tight">{value}</h3>
          </div>
          <div className={`p-3 rounded-lg ${alert ? "bg-destructive/20 text-destructive" : "bg-primary/10 text-primary"}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        {trend && (
          <div className="flex items-center text-sm mt-4">
            <span className={`flex items-center gap-1 font-medium ${trendUp ? "text-emerald-500" : "text-rose-500"}`}>
              {trendUp ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              {trend}
            </span>
            <span className="text-muted-foreground mx-2 text-xs">{t("منذ الأمس", "since yesterday")}</span>
          </div>
        )}
        <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br from-primary/5 to-transparent rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
      </Card>
    </motion.div>
  );
}
