import React, { useState, useRef, useEffect } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Sparkles,
  FileBarChart,
  PieChart,
  TrendingUp,
  Lightbulb,
  Loader2,
  AlertCircle,
  Bot,
} from "lucide-react";
import { GoogleGenAI } from "@google/genai";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

const SYSTEM_PROMPT = `أنت مساعد ذكي متخصص في إدارة مصنع أعلاف اسمه FeedFlow ERP. تساعد المدير في تحليل البيانات والإنتاج والمخزون والمبيعات والموارد البشرية. أجب بالعربية دائماً بشكل مختصر وعملي ومفيد. إذا سُئلت عن بيانات محددة، قدّم أرقاماً واقعية ومعقولة لمصنع أعلاف متوسط الحجم.`;

async function callGemini(messages: Message[], userMessage: string): Promise<string> {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (!apiKey) throw new Error("API key not configured");
  const ai = new GoogleGenAI({ apiKey });
  const history = messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [
      { role: "user", parts: [{ text: SYSTEM_PROMPT }] },
      { role: "model", parts: [{ text: "حسناً، أنا مساعدك الذكي لـ FeedFlow ERP." }] },
      ...history,
      { role: "user", parts: [{ text: userMessage }] },
    ],
    config: { maxOutputTokens: 8192 },
  });
  return response.text ?? "";
}

const INSIGHTS = [
  {
    icon: TrendingUp,
    color: "text-primary",
    borderHover: "hover:border-primary/40",
    titleAr: "توقع الطلب",
    titleEn: "Demand Forecast",
    descAr: "من المتوقع زيادة الطلب على علف تسمين العجول بنسبة 15% الأسبوع القادم.",
    descEn: "Calf fattening feed demand expected to rise 15% next week.",
    qAr: "أخبرني المزيد عن توقع الطلب",
    qEn: "Tell me more about demand forecast",
  },
  {
    icon: FileBarChart,
    color: "text-chart-2",
    borderHover: "hover:border-chart-2/40",
    titleAr: "تحليل التكلفة",
    titleEn: "Cost Analysis",
    descAr: "تكلفة إنتاج طن نامي 21% انخفضت 2% بسبب نزول سعر الصويا.",
    descEn: "Nami 21% production cost dropped 2% due to soy price decrease.",
    qAr: "حلّل تكاليف الإنتاج الشهر الحالي",
    qEn: "Analyze this month's production costs",
  },
  {
    icon: PieChart,
    color: "text-chart-4",
    borderHover: "hover:border-chart-4/40",
    titleAr: "سلوك العملاء",
    titleEn: "Customer Behavior",
    descAr: "مزارع الوطنية تأخرت عن موعد طلبها المعتاد بـ 3 أيام.",
    descEn: "Al-Watania Farms is 3 days late for their usual order.",
    qAr: "ما أفضل عملائي من حيث الالتزام؟",
    qEn: "Who are my most reliable customers?",
  },
];

export default function AiAssistant() {
  const { t } = useAppStore();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: t(
        "مرحباً! أنا مساعدك الذكي لـ FeedFlow ERP. يمكنني مساعدتك في تحليل بيانات المصنع، المبيعات، المخزون، والإنتاج. كيف يمكنني مساعدتك اليوم؟",
        "Hello! I'm your FeedFlow ERP AI Assistant. I can help you analyze factory data, sales, inventory, and production. How can I help you today?"
      ),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const chips = [
    t("كم مبيعات الشهر؟", "Monthly sales?"),
    t("المخزون الحرج", "Critical inventory"),
    t("أفضل عميل", "Top customer"),
    t("توقع الشهر القادم", "Next month forecast"),
  ];

  const sendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    setError(null);
    setInput("");

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: trimmed };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const reply = await callGemini(messages, trimmed);
      setMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: "assistant", content: reply },
      ]);
    } catch {
      setError(t("حدث خطأ أثناء الاتصال. تحقق من المفتاح أو الاتصال.", "Connection error. Check API key or network."));
    } finally {
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  return (
    <div className="flex flex-col" style={{ height: "calc(100vh - 112px)" }}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-4 shrink-0">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-chart-4 flex items-center justify-center text-primary-foreground shadow-md shadow-primary/20 shrink-0">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-xl font-bold leading-tight">{t("المساعد الذكي", "AI Assistant")}</h1>
          <p className="text-muted-foreground text-xs">{t("مدعوم بـ Gemini AI", "Powered by Gemini AI")}</p>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 flex gap-4 min-h-0">

        {/* Chat Panel */}
        <div className="flex-1 flex flex-col min-h-0 rounded-xl border border-primary/20 bg-card shadow-sm overflow-hidden">
          {/* Top bar gradient */}
          <div className="h-0.5 bg-gradient-to-r from-primary via-chart-4 to-primary shrink-0" />

          {/* Messages */}
          <div className="flex-1 min-h-0 overflow-y-auto p-4 flex flex-col gap-3 custom-scrollbar">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.18 }}
                  className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 text-xs font-semibold ${
                      msg.role === "assistant"
                        ? "bg-gradient-to-tr from-primary to-chart-4 text-primary-foreground"
                        : "bg-muted text-muted-foreground border border-border"
                    }`}
                  >
                    {msg.role === "assistant" ? <Bot className="w-3.5 h-3.5" /> : "أنت"}
                  </div>

                  {/* Bubble */}
                  <div
                    className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.role === "assistant"
                        ? "bg-muted/60 rounded-ss-none"
                        : "bg-primary text-primary-foreground rounded-se-none"
                    }`}
                  >
                    {msg.content}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Loading bubble */}
            {loading && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex gap-2"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-primary to-chart-4 flex items-center justify-center text-primary-foreground shrink-0">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="bg-muted/60 rounded-2xl rounded-ss-none px-4 py-2.5 flex items-center gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 px-3 py-2 bg-destructive/10 border border-destructive/20 rounded-lg text-xs text-destructive">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {error}
              </div>
            )}

            <div ref={bottomRef} />
          </div>

          {/* Input Area */}
          <div className="shrink-0 border-t border-border bg-background/80 backdrop-blur-sm p-3">
            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {chips.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(chip)}
                  disabled={loading}
                  className="text-xs text-muted-foreground bg-muted hover:bg-accent hover:text-accent-foreground disabled:opacity-40 disabled:cursor-not-allowed px-2.5 py-1 rounded-full border border-border transition-colors"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Input row */}
            <div className="flex gap-2 items-center">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage(input);
                  }
                }}
                disabled={loading}
                placeholder={t("اسأل المساعد الذكي...", "Ask the AI assistant...")}
                className="flex-1 h-9 px-3 rounded-lg bg-muted/50 border border-border focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none text-sm transition-colors disabled:opacity-50"
              />
              <Button
                size="icon"
                disabled={!input.trim() || loading}
                onClick={() => sendMessage(input)}
                className="h-9 w-9 shrink-0 rounded-lg bg-primary hover:bg-primary/90 disabled:opacity-40"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 rtl:-scale-x-100" />
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Insights Sidebar */}
        <div className="w-64 shrink-0 flex flex-col gap-3 min-h-0">
          <div className="rounded-xl border border-border bg-card shadow-sm p-4 flex flex-col gap-3 flex-1 min-h-0 overflow-y-auto custom-scrollbar">
            <div className="flex items-center gap-2 shrink-0">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span className="font-semibold text-sm">{t("رؤى ذكية", "Smart Insights")}</span>
            </div>

            {INSIGHTS.map((item, i) => {
              const Icon = item.icon;
              return (
                <button
                  key={i}
                  onClick={() => sendMessage(t(item.qAr, item.qEn))}
                  disabled={loading}
                  className={`w-full text-start p-3 rounded-lg bg-background border border-border hover:shadow-sm ${item.borderHover} transition-all disabled:opacity-40 disabled:cursor-not-allowed`}
                >
                  <div className={`flex items-center gap-1.5 mb-1 ${item.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                    <span className="font-semibold text-xs">{t(item.titleAr, item.titleEn)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {t(item.descAr, item.descEn)}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
