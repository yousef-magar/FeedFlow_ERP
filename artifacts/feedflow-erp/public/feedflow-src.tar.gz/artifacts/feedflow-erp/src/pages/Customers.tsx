import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Phone, MapPin, CreditCard, ChevronLeft, CheckCircle2, TrendingUp, Calendar, ShoppingCart, AlertTriangle } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const governorates = ["القاهرة", "الجيزة", "الإسكندرية", "الدقهلية", "البحيرة", "الغربية", "الشرقية", "الوادي الجديد", "أسيوط", "سوهاج"];

export default function Customers() {
  const { t } = useAppStore();
  const [addOpen, setAddOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);

  const [customers, setCustomers] = useState(mockData.customers);

  // Form
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [region, setRegion] = useState("");
  const [governorate, setGovernorate] = useState("");
  const [creditLimit, setCreditLimit] = useState("");

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleSubmit = () => {
    if (!name || !phone || !governorate) return;
    const newCustomer = {
      id: `C${customers.length + 1}`,
      name, phone, address, region, governorate,
      distributionCenter: "DC-New",
      totalPurchases: 0,
      lastPurchase: t("لا يوجد", "None"),
      creditLimit: parseFloat(creditLimit) || 0,
      outstandingDebt: 0,
    };
    setCustomers(prev => [newCustomer, ...prev]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setAddOpen(false);
      setName(""); setPhone(""); setAddress(""); setRegion(""); setGovernorate(""); setCreditLimit("");
    }, 1400);
  };

  const customerHistory = [
    { date: "2023-12-14", action: t("فاتورة مبيعات #INV-001", "Sales Invoice #INV-001"), amount: 245000 },
    { date: "2023-11-30", action: t("تحصيل دفعة", "Payment Collected"), amount: 200000 },
    { date: "2023-11-15", action: t("فاتورة مبيعات #INV-002", "Sales Invoice #INV-002"), amount: 180000 },
    { date: "2023-10-28", action: t("تحصيل دفعة", "Payment Collected"), amount: 150000 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("العملاء", "Customers")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة علاقات العملاء والمديونيات", "Manage customer relationships and debts")}</p>
        </div>
        <Button className="gap-2" onClick={() => setAddOpen(true)} data-testid="button-add-customer">
          <Users className="w-4 h-4" />
          {t("إضافة عميل جديد", "Add Customer")}
        </Button>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {customers.map(customer => (
            <motion.div variants={itemVariants} key={customer.id} layout>
              <Card
                className="p-6 hover:shadow-md transition-shadow group cursor-pointer border-t-4 border-t-transparent hover:border-t-primary"
                data-testid={`card-customer-${customer.id}`}
                onClick={() => { setSelectedCustomer(customer); setProfileOpen(true); }}
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">{customer.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                      <MapPin className="w-3 h-3" />
                      {customer.region}، {customer.governorate}
                    </div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">
                    {customer.name.substring(0, 2)}
                  </div>
                </div>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" /><span dir="ltr">{customer.phone}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <CreditCard className="w-4 h-4" />
                    <span>{t("حد الائتمان:", "Credit Limit:")} <span className="font-semibold text-foreground">{formatCurrency(customer.creditLimit)}</span></span>
                  </div>
                </div>
                <div className="p-3 bg-muted/40 rounded-lg flex justify-between items-center text-sm mb-4">
                  <span className="text-muted-foreground">{t("المديونية", "Debt")}</span>
                  <span className={`font-bold ${customer.outstandingDebt > 0 ? "text-destructive" : "text-emerald-500"}`}>
                    {formatCurrency(customer.outstandingDebt)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-xs text-muted-foreground">{t("آخر شراء:", "Last Purchase:")} {customer.lastPurchase}</span>
                  <span className="text-primary flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {t("التفاصيل", "Details")}
                    <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
                  </span>
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Add Customer Sheet */}
      <Sheet open={addOpen} onOpenChange={setAddOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إضافة عميل جديد", "Add New Customer")}</SheetTitle>
            <SheetDescription>{t("أدخل بيانات العميل الجديد", "Enter new customer details")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("اسم العميل / الشركة", "Customer / Company Name")}</Label>
              <Input placeholder={t("مثال: مزارع الوطنية...", "e.g. Al-Watania Farms...")} value={name} onChange={e => setName(e.target.value)} data-testid="input-customer-name" />
            </div>
            <div className="space-y-2">
              <Label>{t("رقم الهاتف", "Phone Number")}</Label>
              <Input placeholder="01XXXXXXXXX" value={phone} onChange={e => setPhone(e.target.value)} dir="ltr" data-testid="input-customer-phone" />
            </div>
            <div className="space-y-2">
              <Label>{t("العنوان", "Address")}</Label>
              <Input placeholder={t("العنوان التفصيلي", "Detailed address")} value={address} onChange={e => setAddress(e.target.value)} data-testid="input-customer-address" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("المنطقة", "Region")}</Label>
                <Input placeholder={t("مثال: الدلتا", "e.g. Delta")} value={region} onChange={e => setRegion(e.target.value)} data-testid="input-customer-region" />
              </div>
              <div className="space-y-2">
                <Label>{t("المحافظة", "Governorate")}</Label>
                <Select value={governorate} onValueChange={setGovernorate}>
                  <SelectTrigger data-testid="select-customer-governorate"><SelectValue placeholder={t("اختر", "Select")} /></SelectTrigger>
                  <SelectContent>
                    {governorates.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("حد الائتمان (ج.م)", "Credit Limit (EGP)")}</Label>
              <Input type="number" min="0" placeholder="0" value={creditLimit} onChange={e => setCreditLimit(e.target.value)} data-testid="input-customer-credit-limit" />
            </div>
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم الإضافة!", "Customer added!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleSubmit} disabled={!name || !phone || !governorate} data-testid="button-submit-customer">
                    {t("إضافة العميل", "Add Customer")}
                  </Button>
                  <Button variant="outline" onClick={() => setAddOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Customer Profile Sheet */}
      <Sheet open={profileOpen} onOpenChange={setProfileOpen}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          {selectedCustomer && (
            <>
              <SheetHeader className="mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xl">
                    {selectedCustomer.name.substring(0, 2)}
                  </div>
                  <div>
                    <SheetTitle className="text-xl">{selectedCustomer.name}</SheetTitle>
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <MapPin className="w-3 h-3" />{selectedCustomer.region}، {selectedCustomer.governorate}
                    </p>
                  </div>
                </div>
              </SheetHeader>

              <div className="grid grid-cols-2 gap-4 mb-6">
                {[
                  { icon: TrendingUp, label: t("إجمالي المشتريات", "Total Purchases"), value: formatCurrency(selectedCustomer.totalPurchases), color: "text-primary" },
                  { icon: AlertTriangle, label: t("المديونية الحالية", "Current Debt"), value: formatCurrency(selectedCustomer.outstandingDebt), color: selectedCustomer.outstandingDebt > 0 ? "text-destructive" : "text-emerald-500" },
                  { icon: CreditCard, label: t("حد الائتمان", "Credit Limit"), value: formatCurrency(selectedCustomer.creditLimit), color: "text-foreground" },
                  { icon: Calendar, label: t("آخر شراء", "Last Purchase"), value: selectedCustomer.lastPurchase, color: "text-foreground" },
                ].map(({ icon: Icon, label, value, color }) => (
                  <Card key={label} className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{label}</span>
                    </div>
                    <p className={`font-bold text-sm ${color}`}>{value}</p>
                  </Card>
                ))}
              </div>

              <div className="mb-6">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4 text-primary" />
                  {t("سجل المعاملات", "Transaction History")}
                </h4>
                <div className="space-y-3">
                  {customerHistory.map((h, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }} className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                      <div>
                        <p className="text-sm font-medium">{h.action}</p>
                        <p className="text-xs text-muted-foreground">{h.date}</p>
                      </div>
                      <span className="font-bold text-sm text-primary">{formatCurrency(h.amount)}</span>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button className="gap-2" data-testid="button-create-invoice-for-customer">
                  <ShoppingCart className="w-4 h-4" />{t("إنشاء فاتورة", "Create Invoice")}
                </Button>
                <Button variant="outline" className="gap-2" data-testid="button-call-customer">
                  <Phone className="w-4 h-4" />{t("اتصال", "Call")}
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
