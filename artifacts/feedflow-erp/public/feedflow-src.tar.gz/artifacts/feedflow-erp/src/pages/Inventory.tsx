import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Package, AlertCircle, ArrowRightLeft, Plus, CheckCircle2 } from "lucide-react";

const containerVariants = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } };

const warehouses = [
  { id: "W1", name: "المخزن الرئيسي" },
  { id: "W2", name: "مخزن الخامات 2" },
  { id: "W3", name: "مخزن الإضافات" },
];
const units = ["ton", "kg", "bag"];

export default function Inventory() {
  const { t } = useAppStore();
  const [addOpen, setAddOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [transferDone, setTransferDone] = useState(false);

  const [items, setItems] = useState(mockData.inventory);

  // Add form
  const [newMaterial, setNewMaterial] = useState("");
  const [newQty, setNewQty] = useState("");
  const [newUnit, setNewUnit] = useState("ton");
  const [newWarehouse, setNewWarehouse] = useState("");
  const [newExpiry, setNewExpiry] = useState("");

  // Transfer form
  const [transferItem, setTransferItem] = useState("");
  const [fromWarehouse, setFromWarehouse] = useState("");
  const [toWarehouse, setToWarehouse] = useState("");
  const [transferQty, setTransferQty] = useState("");

  const handleAddSubmit = () => {
    if (!newMaterial || !newQty || !newWarehouse) return;
    const newItem = {
      id: `I${items.length + 1}`,
      materialName: newMaterial,
      quantity: parseFloat(newQty),
      unit: newUnit,
      warehouseId: newWarehouse,
      batchNumber: `B-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}`,
      productionDate: new Date().toISOString().split("T")[0],
      expiryDate: newExpiry || "2025-12-31",
      alertLevel: "normal",
    };
    setItems(prev => [newItem, ...prev]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setAddOpen(false);
      setNewMaterial(""); setNewQty(""); setNewUnit("ton"); setNewWarehouse(""); setNewExpiry("");
    }, 1400);
  };

  const handleTransferSubmit = () => {
    if (!transferItem || !fromWarehouse || !toWarehouse || !transferQty) return;
    setTransferDone(true);
    setTimeout(() => {
      setTransferDone(false);
      setTransferOpen(false);
      setTransferItem(""); setFromWarehouse(""); setToWarehouse(""); setTransferQty("");
    }, 1400);
  };

  const getAlertColor = (level: string) => {
    switch (level) {
      case "critical": return "bg-destructive/10 text-destructive border-destructive/20";
      case "warning": return "bg-amber-500/10 text-amber-500 border-amber-500/20";
      default: return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
    }
  };
  const getAlertText = (level: string) => {
    switch (level) {
      case "critical": return t("حرج", "Critical");
      case "warning": return t("تحذير", "Warning");
      default: return t("طبيعي", "Normal");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("المخزون", "Inventory")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة ومراقبة مخزون الخامات والمنتجات", "Manage and monitor raw materials and products")}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setTransferOpen(true)} data-testid="button-transfer-inventory">
            <ArrowRightLeft className="w-4 h-4" />
            {t("نقل بين المخازن", "Transfer")}
          </Button>
          <Button className="gap-2" onClick={() => setAddOpen(true)} data-testid="button-add-inventory-item">
            <Plus className="w-4 h-4" />
            {t("إضافة صنف", "Add Item")}
          </Button>
        </div>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 flex items-center gap-4 border-l-4 border-l-primary">
          <div className="p-3 bg-primary/10 rounded-full text-primary"><Package className="w-6 h-6" /></div>
          <div>
            <p className="text-2xl font-bold">{items.length}</p>
            <p className="text-sm text-muted-foreground">{t("إجمالي الأصناف", "Total Items")}</p>
          </div>
        </Card>
        <Card className="p-4 flex items-center gap-4 border-l-4 border-l-amber-500">
          <div className="p-3 bg-amber-500/10 rounded-full text-amber-500"><AlertCircle className="w-6 h-6" /></div>
          <div>
            <p className="text-2xl font-bold">{items.filter(i => i.alertLevel === "warning").length}</p>
            <p className="text-sm text-muted-foreground">{t("تنبيهات المخزون", "Stock Warnings")}</p>
          </div>
        </Card>
        <Card className="p-4 flex items-center gap-4 border-l-4 border-l-destructive">
          <div className="p-3 bg-destructive/10 rounded-full text-destructive"><AlertCircle className="w-6 h-6" /></div>
          <div>
            <p className="text-2xl font-bold">{items.filter(i => i.alertLevel === "critical").length}</p>
            <p className="text-sm text-muted-foreground">{t("نواقص حرجة", "Critical Shortages")}</p>
          </div>
        </Card>
      </motion.div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
              <tr>
                <th className="px-6 py-4">{t("الصنف", "Item")}</th>
                <th className="px-6 py-4">{t("الكمية", "Quantity")}</th>
                <th className="px-6 py-4">{t("المستودع", "Warehouse")}</th>
                <th className="px-6 py-4">{t("رقم التشغيلة", "Batch No.")}</th>
                <th className="px-6 py-4">{t("تاريخ الصلاحية", "Expiry Date")}</th>
                <th className="px-6 py-4">{t("الحالة", "Status")}</th>
              </tr>
            </thead>
            <motion.tbody variants={containerVariants} initial="hidden" animate="show">
              <AnimatePresence>
                {items.map((item) => (
                  <motion.tr
                    variants={itemVariants} key={item.id} layout
                    className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
                    data-testid={`row-inventory-${item.id}`}
                  >
                    <td className="px-6 py-4 font-medium">{item.materialName}</td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-1">
                        <span>{item.quantity} {item.unit === "ton" ? t("طن", "Ton") : t("كجم", "Kg")}</span>
                        <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full ${item.alertLevel === "critical" ? "bg-destructive" : item.alertLevel === "warning" ? "bg-amber-500" : "bg-emerald-500"}`}
                            initial={{ width: 0 }}
                            animate={{ width: item.alertLevel === "critical" ? "15%" : item.alertLevel === "warning" ? "40%" : "80%" }}
                            transition={{ duration: 0.8 }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">{warehouses.find(w => w.id === item.warehouseId)?.name || item.warehouseId}</td>
                    <td className="px-6 py-4 font-mono text-xs">{item.batchNumber}</td>
                    <td className="px-6 py-4 text-muted-foreground">{item.expiryDate}</td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className={getAlertColor(item.alertLevel)}>{getAlertText(item.alertLevel)}</Badge>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </motion.tbody>
          </table>
        </div>
      </Card>

      {/* Add Item Sheet */}
      <Sheet open={addOpen} onOpenChange={setAddOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إضافة صنف جديد", "Add New Item")}</SheetTitle>
            <SheetDescription>{t("أضف خامة أو منتج جديد إلى المخزون", "Add a new raw material or product to inventory")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("اسم المادة", "Material Name")}</Label>
              <Input placeholder={t("مثال: ذرة صفراء...", "e.g. Yellow Corn...")} value={newMaterial} onChange={e => setNewMaterial(e.target.value)} data-testid="input-inventory-material" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("الكمية", "Quantity")}</Label>
                <Input type="number" min="0" value={newQty} onChange={e => setNewQty(e.target.value)} data-testid="input-inventory-qty" />
              </div>
              <div className="space-y-2">
                <Label>{t("الوحدة", "Unit")}</Label>
                <Select value={newUnit} onValueChange={setNewUnit}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ton">{t("طن", "Ton")}</SelectItem>
                    <SelectItem value="kg">{t("كيلوجرام", "Kg")}</SelectItem>
                    <SelectItem value="bag">{t("شيكارة", "Bag")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("المخزن", "Warehouse")}</Label>
              <Select value={newWarehouse} onValueChange={setNewWarehouse}>
                <SelectTrigger data-testid="select-inventory-warehouse"><SelectValue placeholder={t("اختر المخزن", "Select warehouse")} /></SelectTrigger>
                <SelectContent>
                  {warehouses.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("تاريخ الصلاحية", "Expiry Date")}</Label>
              <Input type="date" value={newExpiry} onChange={e => setNewExpiry(e.target.value)} data-testid="input-inventory-expiry" />
            </div>
            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم الإضافة!", "Item added!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleAddSubmit} disabled={!newMaterial || !newQty || !newWarehouse} data-testid="button-submit-inventory-item">
                    {t("إضافة الصنف", "Add Item")}
                  </Button>
                  <Button variant="outline" onClick={() => setAddOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Transfer Sheet */}
      <Sheet open={transferOpen} onOpenChange={setTransferOpen}>
        <SheetContent side="left" className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("نقل بين المخازن", "Warehouse Transfer")}</SheetTitle>
            <SheetDescription>{t("انقل كميات بين المخازن المختلفة", "Transfer quantities between warehouses")}</SheetDescription>
          </SheetHeader>
          <div className="space-y-5">
            <div className="space-y-2">
              <Label>{t("الصنف", "Item")}</Label>
              <Select value={transferItem} onValueChange={setTransferItem}>
                <SelectTrigger data-testid="select-transfer-item"><SelectValue placeholder={t("اختر الصنف", "Select item")} /></SelectTrigger>
                <SelectContent>
                  {items.map(i => <SelectItem key={i.id} value={i.id}>{i.materialName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("من مخزن", "From")}</Label>
                <Select value={fromWarehouse} onValueChange={setFromWarehouse}>
                  <SelectTrigger><SelectValue placeholder={t("من", "From")} /></SelectTrigger>
                  <SelectContent>
                    {warehouses.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("إلى مخزن", "To")}</Label>
                <Select value={toWarehouse} onValueChange={setToWarehouse}>
                  <SelectTrigger><SelectValue placeholder={t("إلى", "To")} /></SelectTrigger>
                  <SelectContent>
                    {warehouses.filter(w => w.id !== fromWarehouse).map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("الكمية", "Quantity")}</Label>
              <Input type="number" min="1" value={transferQty} onChange={e => setTransferQty(e.target.value)} data-testid="input-transfer-qty" />
            </div>
            <AnimatePresence mode="wait">
              {transferDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم النقل بنجاح!", "Transfer successful!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleTransferSubmit} disabled={!transferItem || !fromWarehouse || !toWarehouse || !transferQty || fromWarehouse === toWarehouse} data-testid="button-submit-transfer">
                    {t("تأكيد النقل", "Confirm Transfer")}
                  </Button>
                  <Button variant="outline" onClick={() => setTransferOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
