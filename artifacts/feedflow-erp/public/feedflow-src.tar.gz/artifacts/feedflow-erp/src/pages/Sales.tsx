import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { mockData } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, FileText, Share2, Plus, Download, CheckCircle2, Trash2, X } from "lucide-react";

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};
const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

interface InvoiceItem { productId: string; productName: string; qty: number; price: number }

export default function Sales() {
  const { t } = useAppStore();
  const { customers, products } = mockData;

  const [createOpen, setCreateOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);

  const [invoices, setInvoices] = useState([
    { id: "INV-2023-001", customerId: "C1", customerName: customers[0].name, type: "wholesale", itemsCount: 4, total: 245000, status: "paid", date: "2023-12-14", discount: 0, tax: 14 },
    { id: "INV-2023-002", customerId: "C2", customerName: customers[1].name, type: "credit", itemsCount: 2, total: 85000, status: "pending", date: "2023-12-14", discount: 5, tax: 14 },
    { id: "INV-2023-003", customerId: "C3", customerName: customers[2].name, type: "cash", itemsCount: 1, total: 15000, status: "paid", date: "2023-12-13", discount: 0, tax: 0 },
    { id: "INV-2023-004", customerId: "C4", customerName: customers[3].name, type: "credit", itemsCount: 5, total: 320000, status: "overdue", date: "2023-11-28", discount: 3, tax: 14 },
  ]);

  // Form state
  const [customerId, setCustomerId] = useState("");
  const [invoiceType, setInvoiceType] = useState("");
  const [discountPct, setDiscountPct] = useState("0");
  const [taxPct, setTaxPct] = useState("14");
  const [items, setItems] = useState<InvoiceItem[]>([{ productId: "", productName: "", qty: 1, price: 0 }]);

  const addItem = () => setItems(prev => [...prev, { productId: "", productName: "", qty: 1, price: 0 }]);
  const removeItem = (i: number) => setItems(prev => prev.filter((_, idx) => idx !== i));
  const updateItem = (i: number, field: keyof InvoiceItem, value: any) => {
    setItems(prev => prev.map((item, idx) => {
      if (idx !== i) return item;
      if (field === "productId") {
        const p = products.find(p => p.id === value);
        return { ...item, productId: value, productName: p?.name || "", price: p?.wholeSalePrice || 0 };
      }
      return { ...item, [field]: value };
    }));
  };

  const subtotal = items.reduce((s, it) => s + (it.qty * it.price), 0);
  const discountAmt = subtotal * (parseFloat(discountPct) || 0) / 100;
  const taxAmt = (subtotal - discountAmt) * (parseFloat(taxPct) || 0) / 100;
  const total = subtotal - discountAmt + taxAmt;

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleSubmit = () => {
    if (!customerId || !invoiceType || items.some(i => !i.productId)) return;
    const cust = customers.find(c => c.id === customerId);
    const newInv = {
      id: `INV-2024-${String(invoices.length + 1).padStart(3, "0")}`,
      customerId,
      customerName: cust?.name || "",
      type: invoiceType,
      itemsCount: items.length,
      total,
      status: invoiceType === "cash" ? "paid" : "pending",
      date: new Date().toISOString().split("T")[0],
      discount: parseFloat(discountPct) || 0,
      tax: parseFloat(taxPct) || 0,
    };
    setInvoices(prev => [newInv, ...prev]);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setCreateOpen(false);
      setCustomerId(""); setInvoiceType(""); setItems([{ productId: "", productName: "", qty: 1, price: 0 }]);
      setDiscountPct("0"); setTaxPct("14");
    }, 1500);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid": return <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t("مدفوع", "Paid")}</Badge>;
      case "pending": return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20">{t("معلق", "Pending")}</Badge>;
      case "overdue": return <Badge className="bg-destructive/10 text-destructive border-destructive/20">{t("متأخر", "Overdue")}</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "wholesale": return <Badge variant="secondary">{t("جملة", "Wholesale")}</Badge>;
      case "credit": return <Badge variant="outline">{t("آجل", "Credit")}</Badge>;
      case "cash": return <Badge className="bg-primary/10 text-primary border-primary/20">{t("نقدي", "Cash")}</Badge>;
      default: return <Badge>{type}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("المبيعات", "Sales")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة الفواتير وعمليات البيع", "Manage invoices and sales operations")}</p>
        </div>
        <Button className="gap-2" onClick={() => setCreateOpen(true)} data-testid="button-create-invoice">
          <Plus className="w-4 h-4" />
          {t("إنشاء فاتورة", "Create Invoice")}
        </Button>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
              <tr>
                <th className="px-6 py-4">{t("رقم الفاتورة", "Invoice ID")}</th>
                <th className="px-6 py-4">{t("العميل", "Customer")}</th>
                <th className="px-6 py-4">{t("النوع", "Type")}</th>
                <th className="px-6 py-4">{t("التاريخ", "Date")}</th>
                <th className="px-6 py-4">{t("الإجمالي", "Total")}</th>
                <th className="px-6 py-4">{t("الحالة", "Status")}</th>
                <th className="px-6 py-4 text-center">{t("إجراءات", "Actions")}</th>
              </tr>
            </thead>
            <motion.tbody variants={containerVariants} initial="hidden" animate="show">
              {invoices.map((inv) => (
                <motion.tr variants={itemVariants} key={inv.id} className="border-b border-border hover:bg-muted/30 transition-colors" data-testid={`row-invoice-${inv.id}`}>
                  <td className="px-6 py-4 font-medium text-primary cursor-pointer hover:underline" onClick={() => { setSelectedInvoice(inv); setDetailOpen(true); }}>{inv.id}</td>
                  <td className="px-6 py-4 font-semibold">{inv.customerName}</td>
                  <td className="px-6 py-4">{getTypeBadge(inv.type)}</td>
                  <td className="px-6 py-4 text-muted-foreground">{inv.date}</td>
                  <td className="px-6 py-4 font-bold">{formatCurrency(inv.total)}</td>
                  <td className="px-6 py-4">{getStatusBadge(inv.status)}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" data-testid={`button-view-invoice-${inv.id}`} onClick={() => { setSelectedInvoice(inv); setDetailOpen(true); }}>
                        <FileText className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" data-testid={`button-download-invoice-${inv.id}`} onClick={() => { setSelectedInvoice(inv); setDetailOpen(true); }}>
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-emerald-500" data-testid={`button-share-invoice-${inv.id}`} onClick={() => { setSelectedInvoice(inv); setShareOpen(true); }}>
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </motion.tbody>
          </table>
        </div>
      </Card>

      {/* Create Invoice Sheet */}
      <Sheet open={createOpen} onOpenChange={setCreateOpen}>
        <SheetContent side="left" className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>{t("إنشاء فاتورة جديدة", "Create New Invoice")}</SheetTitle>
            <SheetDescription>{t("أدخل بيانات الفاتورة والمنتجات", "Enter invoice and product details")}</SheetDescription>
          </SheetHeader>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("العميل", "Customer")}</Label>
                <Select value={customerId} onValueChange={setCustomerId}>
                  <SelectTrigger data-testid="select-invoice-customer">
                    <SelectValue placeholder={t("اختر العميل", "Select customer")} />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t("نوع الفاتورة", "Invoice Type")}</Label>
                <Select value={invoiceType} onValueChange={setInvoiceType}>
                  <SelectTrigger data-testid="select-invoice-type">
                    <SelectValue placeholder={t("اختر النوع", "Select type")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">{t("نقدي", "Cash")}</SelectItem>
                    <SelectItem value="credit">{t("آجل", "Credit")}</SelectItem>
                    <SelectItem value="wholesale">{t("جملة", "Wholesale")}</SelectItem>
                    <SelectItem value="retail">{t("قطاعي", "Retail")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <Label>{t("المنتجات", "Products")}</Label>
                <Button variant="outline" size="sm" onClick={addItem} className="gap-1" data-testid="button-add-invoice-item">
                  <Plus className="w-3 h-3" />{t("إضافة", "Add")}
                </Button>
              </div>
              <div className="space-y-3">
                <AnimatePresence>
                  {items.map((item, i) => (
                    <motion.div key={i} initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-5 space-y-1">
                        {i === 0 && <Label className="text-xs text-muted-foreground">{t("المنتج", "Product")}</Label>}
                        <Select value={item.productId} onValueChange={v => updateItem(i, "productId", v)}>
                          <SelectTrigger className="h-9">
                            <SelectValue placeholder={t("اختر...", "Select...")} />
                          </SelectTrigger>
                          <SelectContent>
                            {products.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-2 space-y-1">
                        {i === 0 && <Label className="text-xs text-muted-foreground">{t("الكمية", "Qty")}</Label>}
                        <Input type="number" min="1" className="h-9" value={item.qty} onChange={e => updateItem(i, "qty", parseInt(e.target.value) || 1)} />
                      </div>
                      <div className="col-span-4 space-y-1">
                        {i === 0 && <Label className="text-xs text-muted-foreground">{t("السعر (ج.م)", "Price (EGP)")}</Label>}
                        <Input type="number" className="h-9" value={item.price} onChange={e => updateItem(i, "price", parseFloat(e.target.value) || 0)} />
                      </div>
                      <div className="col-span-1">
                        {items.length > 1 && (
                          <Button variant="ghost" size="icon" className="h-9 w-9 text-destructive hover:bg-destructive/10" onClick={() => removeItem(i)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("الخصم %", "Discount %")}</Label>
                <Input type="number" min="0" max="100" value={discountPct} onChange={e => setDiscountPct(e.target.value)} data-testid="input-invoice-discount" />
              </div>
              <div className="space-y-2">
                <Label>{t("الضريبة %", "Tax %")}</Label>
                <Input type="number" min="0" max="100" value={taxPct} onChange={e => setTaxPct(e.target.value)} data-testid="input-invoice-tax" />
              </div>
            </div>

            {subtotal > 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-lg border border-border bg-muted/30 p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t("المجموع الجزئي", "Subtotal")}</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                {discountAmt > 0 && (
                  <div className="flex justify-between text-destructive">
                    <span>{t("خصم", "Discount")} {discountPct}%</span>
                    <span>- {formatCurrency(discountAmt)}</span>
                  </div>
                )}
                {taxAmt > 0 && (
                  <div className="flex justify-between text-amber-500">
                    <span>{t("ضريبة", "Tax")} {taxPct}%</span>
                    <span>+ {formatCurrency(taxAmt)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-base border-t border-border pt-2 mt-2">
                  <span>{t("الإجمالي", "Total")}</span>
                  <span className="text-primary">{formatCurrency(total)}</span>
                </div>
              </motion.div>
            )}

            <AnimatePresence mode="wait">
              {submitted ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم إنشاء الفاتورة!", "Invoice created!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1" onClick={handleSubmit} disabled={!customerId || !invoiceType || items.some(i => !i.productId)} data-testid="button-submit-invoice">
                    {t("إنشاء الفاتورة", "Create Invoice")}
                  </Button>
                  <Button variant="outline" onClick={() => setCreateOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </SheetContent>
      </Sheet>

      {/* Invoice Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("تفاصيل الفاتورة", "Invoice Details")}</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-3">
              {[
                [t("رقم الفاتورة", "Invoice No."), selectedInvoice.id],
                [t("العميل", "Customer"), selectedInvoice.customerName],
                [t("التاريخ", "Date"), selectedInvoice.date],
                [t("الأصناف", "Items"), `${selectedInvoice.itemsCount} ${t("صنف", "items")}`],
                [t("الخصم", "Discount"), `${selectedInvoice.discount}%`],
                [t("الضريبة", "Tax"), `${selectedInvoice.tax}%`],
              ].map(([label, val]) => (
                <div key={label} className="flex justify-between py-2 border-b border-border last:border-0">
                  <span className="text-muted-foreground text-sm">{label}</span>
                  <span className="font-semibold text-sm">{val}</span>
                </div>
              ))}
              <div className="flex justify-between py-2 border-t border-border mt-2">
                <span className="font-bold">{t("الإجمالي", "Total")}</span>
                <span className="font-bold text-primary text-lg">{formatCurrency(selectedInvoice.total)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-muted-foreground text-sm">{t("الحالة", "Status")}</span>
                {getStatusBadge(selectedInvoice.status)}
              </div>
              <div className="grid grid-cols-2 gap-2 pt-4">
                <Button variant="outline" className="gap-2">
                  <Download className="w-4 h-4" />{t("تحميل PDF", "Download PDF")}
                </Button>
                <Button variant="outline" className="gap-2 text-emerald-500 border-emerald-500/50 hover:bg-emerald-500/10">
                  <Share2 className="w-4 h-4" />{t("واتساب", "WhatsApp")}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={shareOpen} onOpenChange={setShareOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("مشاركة الفاتورة", "Share Invoice")}</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-3 pt-2">
              <p className="text-sm text-muted-foreground">{t("اختر طريقة المشاركة للفاتورة", "Choose sharing method for invoice")} <span className="font-bold text-foreground">{selectedInvoice.id}</span></p>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { label: t("واتساب", "WhatsApp"), color: "bg-emerald-600 hover:bg-emerald-700 text-white" },
                  { label: t("البريد الإلكتروني", "Email"), color: "" },
                  { label: t("رسالة نصية SMS", "SMS"), color: "" },
                  { label: t("نسخ الرابط", "Copy Link"), color: "" },
                ].map(btn => (
                  <Button key={btn.label} className={`w-full ${btn.color}`} variant={btn.color ? undefined : "outline"} onClick={() => setShareOpen(false)}>
                    {btn.label}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
