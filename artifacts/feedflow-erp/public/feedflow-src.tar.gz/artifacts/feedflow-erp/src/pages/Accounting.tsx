import React, { useState } from "react";
import { useAppStore } from "@/hooks/use-app-store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion, AnimatePresence } from "framer-motion";
import { Calculator, Plus, ArrowRightLeft, CreditCard, Banknote, CheckCircle2, TrendingUp, TrendingDown } from "lucide-react";

export default function Accounting() {
  const { t } = useAppStore();
  const [cashInOpen, setCashInOpen] = useState(false);
  const [cashOutOpen, setCashOutOpen] = useState(false);
  const [cashInDone, setCashInDone] = useState(false);
  const [cashOutDone, setCashOutDone] = useState(false);

  const [balances, setBalances] = useState({ treasury: 450000, bank: 1250000, total: 1700000 });

  const [inAmount, setInAmount] = useState("");
  const [inSource, setInSource] = useState("");
  const [inNote, setInNote] = useState("");
  const [outAmount, setOutAmount] = useState("");
  const [outCategory, setOutCategory] = useState("");
  const [outNote, setOutNote] = useState("");

  const [ledger, setLedger] = useState([
    { id: 1, type: "in", label: t("تحصيل من مزارع الوطنية", "Collection from Al-Watania"), amount: 150000, time: "10:30 ص" },
    { id: 2, type: "out", label: t("شراء خامات ذرة", "Raw material purchase - corn"), amount: 85000, time: "09:15 ص" },
    { id: 3, type: "in", label: t("تحصيل من شركة الأماني", "Collection from Al-Amani"), amount: 75000, time: "08:45 ص" },
  ]);

  const formatCurrency = (num: number) =>
    new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 }).format(num);

  const handleCashIn = () => {
    if (!inAmount || !inSource) return;
    const amount = parseFloat(inAmount);
    setBalances(prev => ({ ...prev, treasury: prev.treasury + amount, total: prev.total + amount }));
    setLedger(prev => [{ id: Date.now(), type: "in", label: inSource + (inNote ? ` — ${inNote}` : ""), amount, time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }) }, ...prev]);
    setCashInDone(true);
    setTimeout(() => { setCashInDone(false); setCashInOpen(false); setInAmount(""); setInSource(""); setInNote(""); }, 1400);
  };

  const handleCashOut = () => {
    if (!outAmount || !outCategory) return;
    const amount = parseFloat(outAmount);
    setBalances(prev => ({ ...prev, treasury: prev.treasury - amount, total: prev.total - amount }));
    setLedger(prev => [{ id: Date.now(), type: "out", label: outCategory + (outNote ? ` — ${outNote}` : ""), amount, time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }) }, ...prev]);
    setCashOutDone(true);
    setTimeout(() => { setCashOutDone(false); setCashOutOpen(false); setOutAmount(""); setOutCategory(""); setOutNote(""); }, 1400);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t("الحسابات والمالية", "Accounting")}</h1>
          <p className="text-muted-foreground mt-1">{t("إدارة الخزينة والبنوك والقيود", "Treasury, banking and ledger management")}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2 text-destructive border-destructive/50 hover:bg-destructive/10" onClick={() => { setCashOutOpen(true); setCashOutDone(false); }} data-testid="button-cash-out">
            <ArrowRightLeft className="w-4 h-4" />
            {t("صرف نقدية", "Cash Out")}
          </Button>
          <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => { setCashInOpen(true); setCashInDone(false); }} data-testid="button-cash-in">
            <Plus className="w-4 h-4" />
            {t("قبض نقدية", "Cash In")}
          </Button>
        </div>
      </div>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-primary/10 text-primary rounded-lg"><Banknote className="w-6 h-6" /></div>
            <h3 className="font-bold text-lg">{t("الخزينة الرئيسية", "Main Treasury")}</h3>
          </div>
          <motion.p key={balances.treasury} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="text-3xl font-bold tracking-tight text-primary">{formatCurrency(balances.treasury)}</motion.p>
          <p className="text-sm text-muted-foreground mt-2">{t("رصيد حالي", "Current Balance")}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-500/10 text-blue-500 rounded-lg"><CreditCard className="w-6 h-6" /></div>
            <h3 className="font-bold text-lg">{t("البنك الأهلي", "NBE Bank")}</h3>
          </div>
          <p className="text-3xl font-bold tracking-tight text-blue-500">{formatCurrency(balances.bank)}</p>
          <p className="text-sm text-muted-foreground mt-2">{t("رصيد حالي", "Current Balance")}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-amber-500/10 text-amber-500 rounded-lg"><Calculator className="w-6 h-6" /></div>
            <h3 className="font-bold text-lg">{t("إجمالي الأصول", "Total Assets")}</h3>
          </div>
          <motion.p key={balances.total} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="text-3xl font-bold tracking-tight text-amber-500">{formatCurrency(balances.total)}</motion.p>
          <p className="text-sm text-muted-foreground mt-2">{t("خزينة + بنوك", "Treasury + Banks")}</p>
        </Card>
      </motion.div>

      {/* Daily Ledger */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4 text-lg">{t("يومية الخزينة", "Daily Cash Ledger")}</h3>
        <div className="space-y-3">
          <AnimatePresence>
            {ledger.map((entry) => (
              <motion.div key={entry.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${entry.type === "in" ? "bg-emerald-500/10" : "bg-destructive/10"}`}>
                    {entry.type === "in"
                      ? <TrendingUp className="w-4 h-4 text-emerald-500" />
                      : <TrendingDown className="w-4 h-4 text-destructive" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{entry.label}</p>
                    <p className="text-xs text-muted-foreground">{entry.time}</p>
                  </div>
                </div>
                <span className={`font-bold ${entry.type === "in" ? "text-emerald-500" : "text-destructive"}`}>
                  {entry.type === "in" ? "+" : "-"}{formatCurrency(entry.amount)}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </Card>

      {/* Cash In Dialog */}
      <Dialog open={cashInOpen} onOpenChange={setCashInOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-emerald-500">{t("قبض نقدية", "Cash In")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t("المبلغ (ج.م)", "Amount (EGP)")}</Label>
              <Input type="number" min="0" placeholder="0" value={inAmount} onChange={e => setInAmount(e.target.value)} data-testid="input-cash-in-amount" />
            </div>
            <div className="space-y-2">
              <Label>{t("المصدر", "Source")}</Label>
              <Select value={inSource} onValueChange={setInSource}>
                <SelectTrigger data-testid="select-cash-in-source"><SelectValue placeholder={t("اختر المصدر", "Select source")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={t("تحصيل من عميل", "Customer collection")}>{t("تحصيل من عميل", "Customer Collection")}</SelectItem>
                  <SelectItem value={t("مبيعات نقدية", "Cash sales")}>{t("مبيعات نقدية", "Cash Sales")}</SelectItem>
                  <SelectItem value={t("إيراد متنوع", "Misc revenue")}>{t("إيراد متنوع", "Miscellaneous")}</SelectItem>
                  <SelectItem value={t("سحب بنكي", "Bank withdrawal")}>{t("سحب بنكي", "Bank Withdrawal")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("ملاحظة (اختياري)", "Note (optional)")}</Label>
              <Input placeholder={t("ملاحظة...", "Note...")} value={inNote} onChange={e => setInNote(e.target.value)} data-testid="input-cash-in-note" />
            </div>
            <AnimatePresence mode="wait">
              {cashInDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم القبض!", "Cash received!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleCashIn} disabled={!inAmount || !inSource} data-testid="button-confirm-cash-in">
                    {t("تأكيد القبض", "Confirm Receipt")}
                  </Button>
                  <Button variant="outline" onClick={() => setCashInOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </DialogContent>
      </Dialog>

      {/* Cash Out Dialog */}
      <Dialog open={cashOutOpen} onOpenChange={setCashOutOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-destructive">{t("صرف نقدية", "Cash Out")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t("المبلغ (ج.م)", "Amount (EGP)")}</Label>
              <Input type="number" min="0" placeholder="0" value={outAmount} onChange={e => setOutAmount(e.target.value)} data-testid="input-cash-out-amount" />
            </div>
            <div className="space-y-2">
              <Label>{t("بند الصرف", "Expense Category")}</Label>
              <Select value={outCategory} onValueChange={setOutCategory}>
                <SelectTrigger data-testid="select-cash-out-category"><SelectValue placeholder={t("اختر البند", "Select category")} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={t("شراء خامات", "Raw materials")}>{t("شراء خامات", "Raw Materials")}</SelectItem>
                  <SelectItem value={t("رواتب", "Salaries")}>{t("رواتب", "Salaries")}</SelectItem>
                  <SelectItem value={t("صيانة", "Maintenance")}>{t("صيانة", "Maintenance")}</SelectItem>
                  <SelectItem value={t("مصروفات تشغيل", "Operating expenses")}>{t("مصروفات تشغيل", "Operating Expenses")}</SelectItem>
                  <SelectItem value={t("إيداع بنكي", "Bank deposit")}>{t("إيداع بنكي", "Bank Deposit")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("ملاحظة (اختياري)", "Note (optional)")}</Label>
              <Input placeholder={t("ملاحظة...", "Note...")} value={outNote} onChange={e => setOutNote(e.target.value)} data-testid="input-cash-out-note" />
            </div>
            <AnimatePresence mode="wait">
              {cashOutDone ? (
                <motion.div key="s" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex items-center justify-center gap-2 py-3 bg-emerald-500/10 text-emerald-500 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" /><span className="font-medium">{t("تم الصرف!", "Cash disbursed!")}</span>
                </motion.div>
              ) : (
                <motion.div key="b" className="flex gap-3">
                  <Button className="flex-1 bg-destructive hover:bg-destructive/90 text-white" onClick={handleCashOut} disabled={!outAmount || !outCategory} data-testid="button-confirm-cash-out">
                    {t("تأكيد الصرف", "Confirm Payment")}
                  </Button>
                  <Button variant="outline" onClick={() => setCashOutOpen(false)}>{t("إلغاء", "Cancel")}</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
